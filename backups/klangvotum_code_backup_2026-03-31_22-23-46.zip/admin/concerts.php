<?php
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/layout.php';

$admin = sv_require_admin();
$pdo   = sv_pdo();
$base  = sv_base_url();

// ── POST-Aktionen ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  sv_csrf_check();
  $action = $_POST['action'] ?? '';

  if ($action === 'create' || $action === 'update') {
    $cid      = (int)($_POST['cid'] ?? 0);
    $name     = trim($_POST['name']     ?? '');
    $date     = trim($_POST['date']     ?? '') ?: null;
    $location = trim($_POST['location'] ?? '') ?: null;
    $notes    = trim($_POST['notes']    ?? '') ?: null;

    if ($name === '') {
      sv_flash_set('error', 'Name ist Pflichtfeld.');
    } else {
      try {
        if ($action === 'create') {
          $pdo->prepare("INSERT INTO concerts (name, date, location, notes) VALUES (?,?,?,?)")
            ->execute([$name, $date, $location, $notes]);
          $cid = (int)$pdo->lastInsertId();
          sv_log($admin['id'], 'concert_create', $name);
          sv_flash_set('success', 'Auftritt angelegt.');
        } else {
          $pdo->prepare("UPDATE concerts SET name=?, date=?, location=?, notes=? WHERE id=?")
            ->execute([$name, $date, $location, $notes, $cid]);
          sv_log($admin['id'], 'concert_update', "cid=$cid");
          sv_flash_set('success', 'Auftritt aktualisiert.');
        }
      } catch (Throwable $e) {
        sv_flash_set('error', 'Fehler: ' . $e->getMessage());
      }
    }
    header('Location: ' . $base . '/admin/concerts.php');
    exit;

  } elseif ($action === 'delete') {
    $cid = (int)($_POST['cid'] ?? 0);
    if ($cid) {
      $pdo->prepare("DELETE FROM concerts WHERE id=?")->execute([$cid]);
      sv_log($admin['id'], 'concert_delete', "cid=$cid");
      sv_flash_set('success', 'Auftritt gelöscht.');
    }
    header('Location: ' . $base . '/admin/concerts.php');
    exit;

  } elseif ($action === 'add_piece') {
    $cid = (int)($_POST['cid'] ?? 0);
    $pid = (int)($_POST['pid'] ?? 0);
    if ($cid && $pid) {
      try {
        $maxPos = (int)($pdo->prepare("SELECT COALESCE(MAX(position),0) FROM concert_pieces WHERE concert_id=?")
          ->execute([$cid]) ? $pdo->query("SELECT COALESCE(MAX(position),0) FROM concert_pieces WHERE concert_id=$cid")->fetchColumn() : 0);
        $pdo->prepare("INSERT IGNORE INTO concert_pieces (concert_id, piece_id, position) VALUES (?,?,?)")
          ->execute([$cid, $pid, $maxPos + 1]);
      } catch (Throwable $e) {}
    }
    header('Location: ' . $base . '/admin/concerts.php?cid=' . $cid);
    exit;

  } elseif ($action === 'remove_piece') {
    $cid = (int)($_POST['cid'] ?? 0);
    $pid = (int)($_POST['pid'] ?? 0);
    if ($cid && $pid) {
      $pdo->prepare("DELETE FROM concert_pieces WHERE concert_id=? AND piece_id=?")->execute([$cid, $pid]);
    }
    header('Location: ' . $base . '/admin/concerts.php?cid=' . $cid);
    exit;
  }
}

// ── Daten laden ───────────────────────────────────────────────────────────────
$search    = trim($_GET['q'] ?? '');
$selectedId = (int)($_GET['cid'] ?? 0);

$where  = $search ? "WHERE name LIKE ? OR location LIKE ?" : "";
$params = $search ? ["%$search%", "%$search%"] : [];

$stmt = $pdo->prepare("SELECT * FROM concerts $where ORDER BY date DESC, id DESC");
$stmt->execute($params);
$concerts = $stmt->fetchAll();

$selected = null;
$selPieces = [];
$allPieces = [];

if ($selectedId) {
  $s = $pdo->prepare("SELECT * FROM concerts WHERE id=?"); $s->execute([$selectedId]);
  $selected = $s->fetch();
  if ($selected) {
    $sp = $pdo->prepare("
      SELECT cp.position, p.*
      FROM concert_pieces cp
      JOIN pieces p ON p.id = cp.piece_id
      WHERE cp.concert_id = ?
      ORDER BY cp.position ASC, p.title ASC
    "); $sp->execute([$selectedId]);
    $selPieces = $sp->fetchAll();
    $usedIds = array_column($selPieces, 'id');
    $allPieces = $pdo->query("SELECT id, title, composer, arranger, duration FROM pieces ORDER BY title ASC")->fetchAll();
  }
}

sv_header('Admin – Auftrittskronik', $admin);
?>
<div class="page-header">
  <div>
    <h2>Auftrittskronik</h2>
    <div class="muted">Konzerte und Auftritte dokumentieren</div>
  </div>
  <div class="row">
    <a class="btn primary" href="#" data-open-dialog="dialog-new-concert">+ Neuer Auftritt</a>
    <?php if(file_exists(__DIR__.'/concerts_import.php')): ?>
    <a class="btn" href="<?=h($base)?>/admin/concerts_import.php">📥 Excel importieren</a>
    <?php endif; ?>
    <a class="btn" href="<?=h($base)?>/admin/">← Admin</a>
  </div>
</div>

<div style="display:grid;grid-template-columns:360px 1fr;gap:16px;align-items:start">

  <!-- Linke Spalte: Liste -->
  <div>
    <div class="card" style="margin-bottom:12px">
      <form method="get" style="display:flex;gap:8px">
        <input class="input" type="search" name="q" value="<?=h($search)?>" placeholder="Suche…" style="flex:1">
        <?php if($selectedId): ?><input type="hidden" name="cid" value="<?=$selectedId?>"><?php endif; ?>
        <button class="btn primary" type="submit">Suchen</button>
        <?php if($search): ?><a class="btn" href="concerts.php<?=$selectedId?'?cid='.$selectedId:''?>">Reset</a><?php endif; ?>
      </form>
    </div>

    <div class="card" style="padding:0;overflow:hidden">
      <?php if (!$concerts): ?>
        <div style="padding:20px" class="small"><?= $search ? 'Keine Treffer.' : 'Noch keine Auftritte angelegt.' ?></div>
      <?php endif; ?>
      <?php foreach ($concerts as $c): ?>
        <?php $isActive = $selectedId === (int)$c['id']; ?>
        <div style="padding:12px 14px;border-bottom:1px solid var(--border);<?=$isActive?'background:#f0f5e8;border-left:3px solid var(--green)':''?>">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
            <a href="?cid=<?=h($c['id'])?><?=$search?'&q='.urlencode($search):''?>" style="text-decoration:none;flex:1">
              <div style="font-weight:700;font-size:13px;color:var(--text)"><?=h($c['name'])?></div>
              <div class="small" style="color:var(--muted);margin-top:2px">
                <?php if($c['date']): ?><span><?=date('d.m.Y', strtotime($c['date']))?></span><?php endif; ?>
                <?php if($c['location']): ?><span> · <?=h($c['location'])?></span><?php endif; ?>
              </div>
            </a>
            <div style="position:relative;display:inline-block;flex-shrink:0">
              <button class="btn" style="padding:3px 8px;font-size:14px" onclick="toggleMenu(this)">⋯</button>
              <div class="piece-menu" style="display:none;position:fixed;background:#fff;border:1.5px solid var(--border);border-radius:12px;box-shadow:0 4px 16px rgba(0,0,0,.1);z-index:9999;min-width:160px;overflow:hidden">
                <button class="piece-menu-item" type="button" data-open-dialog="dialog-edit-<?=h($c['id'])?>" onclick="closeMenus()">✏️ Bearbeiten</button>
                <form method="post" onsubmit="return confirm('Auftritt löschen? Alle Stückverknüpfungen werden ebenfalls gelöscht.')">
                  <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="cid" value="<?=h($c['id'])?>">
                  <button class="piece-menu-item" type="submit" style="color:var(--red)">🗑 Löschen</button>
                </form>
              </div>
            </div>
          </div>
          <?php
            $cnt = (int)$pdo->prepare("SELECT COUNT(*) FROM concert_pieces WHERE concert_id=?")->execute([$c['id']]) ?
              $pdo->query("SELECT COUNT(*) FROM concert_pieces WHERE concert_id=".(int)$c['id'])->fetchColumn() : 0;
          ?>
          <?php if($cnt): ?><div class="small" style="color:var(--green);margin-top:4px">🎵 <?=$cnt?> Stück<?=$cnt!==1?'e':''?></div><?php endif; ?>
        </div>

        <!-- Edit Dialog -->
        <dialog id="dialog-edit-<?=h($c['id'])?>" class="sv-dialog">
          <div class="sv-dialog__panel" tabindex="-1">
            <div class="sv-dialog__head">
              <div class="sv-dialog__title">Auftritt bearbeiten</div>
              <button class="sv-dialog__close" type="button" data-close-dialog>✕</button>
            </div>
            <div class="sv-dialog__section">
              <?= concertForm($c, 'update') ?>
            </div>
          </div>
        </dialog>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Rechte Spalte: Detail -->
  <div>
    <?php if ($selected): ?>
    <div class="card" style="margin-bottom:12px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
        <div>
          <h3 style="margin-bottom:4px"><?=h($selected['name'])?></h3>
          <div class="small" style="color:var(--muted)">
            <?php if($selected['date']): ?><?=date('d.m.Y', strtotime($selected['date']))?><?php endif; ?>
            <?php if($selected['location']): ?> · <?=h($selected['location'])?><?php endif; ?>
          </div>
          <?php if($selected['notes']): ?><div class="small" style="margin-top:6px"><?=nl2br(h($selected['notes']))?></div><?php endif; ?>
        </div>
        <button class="btn primary" type="button" data-open-dialog="dialog-edit-<?=$selectedId?>">✏️ Bearbeiten</button>
      </div>
    </div>

    <!-- Programm -->
    <div class="card" style="margin-bottom:12px">
      <h3 style="margin-bottom:12px">🎵 Programm (<?=count($selPieces)?> Stücke)</h3>
      <?php if ($selPieces): ?>
      <table>
        <thead><tr>
          <th style="width:30px">#</th>
          <th>Titel</th>
          <th>Komponist / Arrangeur</th>
          <th style="width:60px">Länge</th>
          <th style="width:40px"></th>
        </tr></thead>
        <tbody>
        <?php foreach ($selPieces as $i => $p): ?>
          <tr>
            <td class="small" style="color:var(--muted);text-align:center"><?=$i+1?></td>
            <td><strong><?=h($p['title'])?></strong>
              <?php if(!empty($p['querverweis'])): ?><span class="small" style="color:var(--muted)"> / <?=h($p['querverweis'])?></span><?php endif; ?>
            </td>
            <td class="small" style="color:var(--muted)">
              <?=h($p['composer']??'')?>
              <?php if(!empty($p['arranger'])): ?><div style="font-size:11px">Arr. <?=h($p['arranger'])?></div><?php endif; ?>
            </td>
            <td class="small" style="white-space:nowrap"><?=h($p['duration']??'–')?></td>
            <td>
              <form method="post">
                <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
                <input type="hidden" name="action" value="remove_piece">
                <input type="hidden" name="cid" value="<?=$selectedId?>">
                <input type="hidden" name="pid" value="<?=h($p['id'])?>">
                <button class="btn danger" type="submit" style="padding:2px 7px;font-size:12px" title="Entfernen">✕</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php
          // Gesamtdauer
          $totalSec = 0;
          foreach ($selPieces as $p) {
            $d = $p['duration'] ?? '';
            if (preg_match('/^(\d+):(\d{2})$/', $d, $m)) $totalSec += (int)$m[1]*60 + (int)$m[2];
            elseif (preg_match("/^(\d+)'(\d{2})$/", $d, $m)) $totalSec += (int)$m[1]*60 + (int)$m[2];
          }
          if ($totalSec > 0):
            $tm = floor($totalSec/60); $ts = $totalSec%60;
        ?>
        <tr style="border-top:2px solid var(--border)">
          <td colspan="3" style="font-weight:700;text-align:right;padding-right:12px">Gesamtdauer:</td>
          <td class="small" style="font-weight:700;white-space:nowrap"><?=$tm?>:<?=str_pad($ts,2,'0',STR_PAD_LEFT)?></td>
          <td></td>
        </tr>
        <?php endif; ?>
        </tbody>
      </table>
      <?php else: ?>
        <div class="small" style="color:var(--muted)">Noch keine Stücke hinzugefügt.</div>
      <?php endif; ?>
    </div>

    <!-- Stück hinzufügen -->
    <div class="card">
      <h3 style="margin-bottom:12px">Stück hinzufügen</h3>
      <form method="post" style="display:flex;gap:8px;align-items:flex-end">
        <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
        <input type="hidden" name="action" value="add_piece">
        <input type="hidden" name="cid" value="<?=$selectedId?>">
        <label style="flex:1">
          <div class="select-wrap">
            <select name="pid" required style="width:100%">
              <option value="">— Stück wählen —</option>
              <?php
                $usedIds = array_column($selPieces, 'id');
                foreach ($allPieces as $ap):
                  $inUse = in_array((int)$ap['id'], array_map('intval', $usedIds));
              ?>
              <option value="<?=h($ap['id'])?>" <?=$inUse?'disabled style="color:#ccc"':''?>>
                <?=h($ap['title'])?><?php if($ap['composer']||$ap['arranger']): ?> (<?=h($ap['composer']??'')?><?=$ap['arranger']?' / Arr. '.h($ap['arranger']):'')?>)<?php endif; ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
        </label>
        <button class="btn primary" type="submit">+ Hinzufügen</button>
      </form>
    </div>

    <?php else: ?>
    <div class="card" style="display:flex;align-items:center;justify-content:center;min-height:200px;color:var(--muted)">
      ← Auftritt aus der Liste auswählen
    </div>
    <?php endif; ?>
  </div>

</div>

<!-- Neuer Auftritt Dialog -->
<dialog id="dialog-new-concert" class="sv-dialog">
  <div class="sv-dialog__panel" tabindex="-1">
    <div class="sv-dialog__head">
      <div class="sv-dialog__title">Neuer Auftritt</div>
      <button class="sv-dialog__close" type="button" data-close-dialog>✕</button>
    </div>
    <div class="sv-dialog__section">
      <?= concertForm(null, 'create') ?>
    </div>
  </div>
</dialog>

<?php

function concertForm(?array $c, string $action): string {
  $v = fn(string $k) => htmlspecialchars((string)($c[$k] ?? ''), ENT_QUOTES, 'UTF-8');
  $cid = $c ? (int)$c['id'] : 0;
  ob_start();
?>
<form method="post" class="grid" style="gap:12px">
  <input type="hidden" name="csrf" value="<?=htmlspecialchars(sv_csrf_token(),ENT_QUOTES)?>">
  <input type="hidden" name="action" value="<?=htmlspecialchars($action,ENT_QUOTES)?>">
  <?php if($cid): ?><input type="hidden" name="cid" value="<?=$cid?>"><?php endif; ?>

  <label style="grid-column:1/-1">Name / Bezeichnung *<br>
    <input name="name" required value="<?=$v('name')?>" placeholder="z.B. Jahreskonzert 2024" style="width:100%;margin-top:5px">
  </label>
  <label>Datum<br>
    <input type="date" name="date" value="<?=$v('date')?>" style="width:100%;margin-top:5px">
  </label>
  <label>Ort<br>
    <input name="location" value="<?=$v('location')?>" placeholder="z.B. Stadthalle Hildesheim" style="width:100%;margin-top:5px">
  </label>
  <label style="grid-column:1/-1">Notizen<br>
    <textarea name="notes" rows="3" style="width:100%;margin-top:5px"><?=$v('notes')?></textarea>
  </label>
  <div style="grid-column:1/-1;display:flex;gap:8px">
    <button class="btn primary" type="submit"><?= $action==='create' ? 'Anlegen' : 'Speichern' ?></button>
    <button class="btn" type="button" data-close-dialog>Abbrechen</button>
  </div>
</form>
<?php
  return ob_get_clean();
}

sv_footer();
?>

<style>
.piece-menu-item { display:block;width:100%;text-align:left;padding:9px 14px;font-size:13px;font-weight:600;background:none;border:none;cursor:pointer;color:var(--text);border-bottom:1px solid var(--border); }
.piece-menu-item:last-child { border-bottom:none; }
.piece-menu-item:hover { background:#faf8f5; }
.piece-menu form { margin:0; }
</style>
<script>
function toggleMenu(btn) {
  var menu = btn.nextElementSibling;
  var isOpen = menu.style.display !== 'none';
  closeMenus();
  if (!isOpen) {
    menu.style.display = 'block';
    var r = btn.getBoundingClientRect();
    var mh = menu.offsetHeight || 100;
    menu.style.top  = (window.innerHeight - r.bottom < mh+8) ? (r.top-mh-4)+'px' : (r.bottom+4)+'px';
    menu.style.right = (window.innerWidth - r.right)+'px';
    setTimeout(function(){ document.addEventListener('click', closeOnOutside); }, 0);
  }
}
function closeMenus() {
  document.querySelectorAll('.piece-menu').forEach(function(m){ m.style.display='none'; });
  document.removeEventListener('click', closeOnOutside);
}
function closeOnOutside(e) {
  if (!e.target.closest('.piece-menu') && !e.target.closest('[onclick*="toggleMenu"]')) closeMenus();
}
document.addEventListener('click', function(e) {
  var openBtn = e.target.closest('[data-open-dialog]');
  if (openBtn) { var d = document.getElementById(openBtn.getAttribute('data-open-dialog')); if(d) d.showModal(); return; }
  var closeBtn = e.target.closest('[data-close-dialog]');
  if (closeBtn) { var d = closeBtn.closest('dialog'); if(d) d.close(); }
});
</script>
