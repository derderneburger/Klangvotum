<?php
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/layout.php';

$admin = sv_require_admin();
$pdo   = sv_pdo();
$base  = sv_base_url();


function pieceForm(?array $p, string $action): string {
  $v = function(string $k) use ($p): string {
    return htmlspecialchars((string)($p[$k] ?? ''), ENT_QUOTES, 'UTF-8');
  };
  $pid = $p ? (int)$p['id'] : 0;
  ob_start();
?>
<form method="post" class="grid" style="gap:12px">
  <input type="hidden" name="csrf" value="<?=htmlspecialchars(sv_csrf_token(),ENT_QUOTES)?>">
  <input type="hidden" name="action" value="<?=htmlspecialchars($action,ENT_QUOTES)?>">
  <?php if($pid): ?><input type="hidden" name="pid" value="<?=$pid?>"><?php endif; ?>
  <input type="hidden" name="_q"    value="<?=h($_GET['q']    ?? '')?>">
  <input type="hidden" name="_sort" value="<?=h($_GET['sort'] ?? '')?>">
  <input type="hidden" name="_dir"  value="<?=h($_GET['dir']  ?? '')?>">
  <input type="hidden" name="_page" value="<?=h($_GET['page'] ?? '')?>">

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px" class="form-grid-2-inner">
    <label style="grid-column:1/-1">Titel *<br><input name="title" required value="<?=$v('title')?>" style="width:100%;margin-top:5px"></label>
    <label style="grid-column:1/-1">YouTube URL<br><input name="youtube_url" value="<?=$v('youtube_url')?>" placeholder="https://youtu.be/…" style="width:100%;margin-top:5px"></label>
    <label>Komponist<br><input name="composer" value="<?=$v('composer')?>" style="width:100%;margin-top:5px"></label>
    <label>Arrangeur<br><input name="arranger" value="<?=$v('arranger')?>" style="width:100%;margin-top:5px"></label>
    <div style="grid-column:1/-1;display:flex;gap:8px">
      <button type="button" class="btn" style="flex:1;justify-content:center" onclick="openSearchWindow(this, 'google')">🌐 Google-Suche</button>
      <button type="button" class="btn" style="flex:1;justify-content:center" onclick="openSearchWindow(this, 'youtube')">▶ YouTube-Suche</button>
    </div>
    <label>Verlag<br><input name="publisher" value="<?=$v('publisher')?>" style="width:100%;margin-top:5px"></label>
    <label>Länge<br><input name="duration" value="<?=$v('duration')?>" placeholder="z.B. 6:30" style="width:100%;margin-top:5px"></label>
    <label>Genre<br><input name="genre" value="<?=$v('genre')?>" placeholder="z.B. Konzertmarsch" style="width:100%;margin-top:5px"></label>
    <label>Gradsgrad (1.0–6.0)<br><input name="difficulty" type="number" step="0.1" min="1" max="6" value="<?=$v('difficulty')?>" style="width:100%;margin-top:5px"></label>
    <label>Eigentümer<br><input name="owner" value="<?=$v('owner')?>" placeholder="z.B. BPH, M.Müller" style="width:100%;margin-top:5px"></label>
    <label>Preis (€)<br><input name="shop_price" type="number" step="0.01" min="0" value="<?=$v('shop_price')?>" style="width:100%;margin-top:5px"></label>
    <label style="grid-column:1/-1">Link zum Händler / Notenversand<br><input name="shop_url" value="<?=$v('shop_url')?>" placeholder="https://…" style="width:100%;margin-top:5px"></label>
    <label style="grid-column:1/-1">Querverweis <span style="font-weight:400;color:var(--muted);font-size:12px">(optional – z.B. „The Happy Cyclist")</span><br><input name="querverweis" value="<?=$v('querverweis')?>" placeholder="Alternativer Titel der in derselben Mappe liegt" style="width:100%;margin-top:5px"></label>
    <label style="grid-column:1/-1">Info-Text<br><textarea name="info" rows="2" style="width:100%;margin-top:5px"><?=$v('info')?></textarea></label>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
    <label class="toggle-wrap">
      <input type="checkbox" name="has_scan" value="1" <?= !empty($p['has_scan']) ? 'checked' : '' ?>>
      <span class="toggle-track"></span>
      <span class="toggle-label">Stimmen eingescannt</span>
    </label>
    <label class="toggle-wrap">
      <input type="checkbox" name="has_score_scan" value="1" <?= !empty($p['has_score_scan']) ? 'checked' : '' ?>>
      <span class="toggle-track"></span>
      <span class="toggle-label">Partitur eingescannt</span>
    </label>
    <label class="toggle-wrap">
      <input type="checkbox" name="has_original_score" value="1" <?= !empty($p['has_original_score']) ? 'checked' : '' ?>>
      <span class="toggle-track"></span>
      <span class="toggle-label">Originalpartitur vorhanden</span>
    </label>
    <label class="toggle-wrap">
      <input type="checkbox" name="binder" value="1" <?= !empty($p['binder']) ? 'checked' : '' ?>>
      <span class="toggle-track"></span>
      <span class="toggle-label">Mappe</span>
    </label>
  </div>

  <div class="row" style="gap:10px">
    <button class="btn primary" type="submit"><?= $action==='create' ? 'Anlegen' : 'Speichern' ?></button>
    <button class="btn" type="button" data-close-dialog>Abbrechen</button>
  </div>
</form>
<?php
  return ob_get_clean();
}


// ── POST-Aktionen ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  sv_csrf_check();
  $action = $_POST['action'] ?? '';

  if ($action === 'create' || $action === 'update') {
    $pid       = (int)($_POST['pid'] ?? 0);
    $title      = trim($_POST['title']       ?? '');
    $youtube_url = trim($_POST['youtube_url'] ?? '');
    $composer  = trim($_POST['composer'] ?? '');
    $arranger  = trim($_POST['arranger'] ?? '');
    $publisher = trim($_POST['publisher'] ?? '');
    $duration  = sv_normalize_duration(trim($_POST['duration'] ?? ''));
    $genre     = trim($_POST['genre']    ?? '');
    $diff      = $_POST['difficulty'] !== '' ? (float)str_replace(',','.',$_POST['difficulty']) : null;
    $owner     = trim($_POST['owner'] ?? '');
    $has_scan        = !empty($_POST['has_scan']) ? 1 : 0;
    $has_score_scan  = !empty($_POST['has_score_scan']) ? 1 : 0;
    $has_orig_score  = !empty($_POST['has_original_score']) ? 1 : 0;
    $folder    = $_POST['folder_number'] !== '' ? (int)$_POST['folder_number'] : null;
    $binder    = !empty($_POST['binder']) ? 'x' : '';
    $shop_url  = trim($_POST['shop_url']   ?? '');
    $shop_price= $_POST['shop_price'] !== '' ? (float)str_replace(',','.',$_POST['shop_price']) : null;
    $info        = trim($_POST['info']        ?? '');
    $notes       = trim($_POST['notes']       ?? '');
    $querverweis = trim($_POST['querverweis'] ?? '');

    if ($title === '') {
      sv_flash_set('error', 'Titel ist Pflichtfeld.');
    } elseif ($diff !== null && ($diff < 1.0 || $diff > 6.0)) {
      sv_flash_set('error', 'Gradsgrad muss zwischen 1.0 und 6.0 liegen.');
    } else {
      try {
        if ($action === 'create') {
          $stmt = $pdo->prepare("INSERT INTO pieces
            (title,youtube_url,composer,arranger,publisher,duration,genre,difficulty,owner,
             has_scan,has_score_scan,has_original_score,folder_number,binder,shop_url,shop_price,info,notes,querverweis)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
          $stmt->execute([$title,$youtube_url,$composer,$arranger,$publisher,$duration,$genre,$diff,$owner,
            $has_scan,$has_score_scan,$has_orig_score,$folder,$binder,$shop_url,$shop_price,$info,$notes,$querverweis]);
          sv_log($admin['id'], 'piece_create', $title);
          sv_flash_set('success', 'Stück angelegt.');
        } else {
          $stmt = $pdo->prepare("UPDATE pieces SET
            title=?,youtube_url=?,composer=?,arranger=?,publisher=?,duration=?,genre=?,difficulty=?,owner=?,
            has_scan=?,has_score_scan=?,has_original_score=?,folder_number=?,binder=?,shop_url=?,shop_price=?,info=?,notes=?,querverweis=?
            WHERE id=?");
          $stmt->execute([$title,$youtube_url,$composer,$arranger,$publisher,$duration,$genre,$diff,$owner,
            $has_scan,$has_score_scan,$has_orig_score,$folder,$binder,$shop_url,$shop_price,$info,$notes,$querverweis,$pid]);
          // Sync zu verknuepften Abstimmungstiteln
          $linkedS = $pdo->prepare("SELECT id FROM songs WHERE piece_id=?"); $linkedS->execute([$pid]);
          $linkedIds = array_column($linkedS->fetchAll(), 'id');
          foreach ($linkedIds as $songId) {
            $pdo->prepare("UPDATE songs SET title=?,youtube_url=?,composer=?,arranger=?,publisher=?,duration=?,genre=?,difficulty=?,shop_url=?,shop_price=?,info=? WHERE id=?")
              ->execute([$title,$youtube_url,$composer,$arranger,$publisher,$duration,$genre,$diff,$shop_url,$shop_price,$info,$songId]);
          }
          sv_log($admin['id'], 'piece_update', "pid=$pid".($linkedIds?" sync=".implode(',',$linkedIds):''));
          sv_flash_set('success', 'Stueck aktualisiert.'.($linkedIds?' ('.count($linkedIds).' Abstimmungstitel synchronisiert)':''));
        }
      } catch (Throwable $e) {
        $msg = $e->getMessage();
        if (strpos($msg, '1062') !== false || strpos($msg, 'Duplicate') !== false) {
          sv_flash_set('error', 'Ein Stück mit diesem Titel und Arrangeur existiert bereits im Archiv. Bitte prüfe ob du es über die Suche findest.');
        } else {
          sv_flash_set('error', 'Fehler: ' . $msg);
        }
      }
    }

  } elseif ($action === 'delete') {
    $pid = (int)($_POST['pid'] ?? 0);
    if ($pid > 0) {
      $pdo->prepare("DELETE FROM pieces WHERE id=?")->execute([$pid]);
      sv_log($admin['id'], 'piece_delete', "pid=$pid");
      sv_flash_set('success', 'Stück gelöscht.');
    }

  } elseif ($action === 'to_song') {
    $pid = (int)($_POST['pid'] ?? 0);
    if ($pid > 0) {
      $piece = $pdo->prepare("SELECT * FROM pieces WHERE id=?");
      $piece->execute([$pid]);
      $p = $piece->fetch();
      if ($p) {
        $existing = $pdo->prepare("SELECT id FROM songs WHERE piece_id=? AND is_active=1");
        $existing->execute([$pid]);
        if ($existing->fetch()) {
          sv_flash_set('error', 'Dieses Stück steht bereits aktiv zur Abstimmung.');
        } else {
          $stmt = $pdo->prepare("INSERT INTO songs
            (title, youtube_url, is_active, piece_id, composer, arranger, publisher, duration, genre, difficulty, shop_url, shop_price, info)
            VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
          $stmt->execute([
            $p['title'], $p['youtube_url'] ?? '', $pid,
            $p['composer'], $p['arranger'], $p['publisher'],
            $p['duration'], $p['genre'], $p['difficulty'],
            $p['shop_url'], $p['shop_price'], $p['info'],
          ]);
          $newSongId = (int)$pdo->lastInsertId();
          $oldVotes = $pdo->prepare("SELECT COUNT(DISTINCT v.user_id) AS cnt FROM votes v JOIN songs s ON s.id=v.song_id WHERE s.piece_id=? AND s.id!=?");
          $oldVotes->execute([$pid, $newSongId]);
          $oldVoteCount = (int)$oldVotes->fetchColumn();
          sv_log($admin['id'], 'piece_to_song', "pid=$pid title={$p['title']}");
          $youtubeHint = empty($p['youtube_url']) ? ' YouTube-URL bitte in Titel-Verwaltung ergänzen.' : '';
          $msg = '„'.$p['title'].'“ zur Abstimmung gestellt.'.$youtubeHint;
          if ($oldVoteCount > 0) $msg .= ' '.$oldVoteCount.' Musiker haben früher abgestimmt — sie sehen ihre alte Stimme als Hinweis.';
          sv_flash_set($youtubeHint ? 'warning' : 'success', $msg);
        }
      }
    }
  }

  $redirectParams = array_filter([
    'q'    => $_POST['_q']    ?? '',
    'sort' => $_POST['_sort'] ?? '',
    'dir'  => $_POST['_dir']  ?? '',
    'page' => $_POST['_page'] ?? '',
  ]);
  $redirectSuffix = $redirectParams ? '?' . http_build_query($redirectParams) : '';
  header('Location: ' . $base . '/admin/bibliothek.php' . $redirectSuffix);
  exit;
}

// ── Daten laden ───────────────────────────────────────────────────────────────
$search  = trim($_GET['q']      ?? '');
$sortBy  = in_array($_GET['sort'] ?? '', ['title','composer','arranger','genre','difficulty','duration','owner','scan','binder']) ? $_GET['sort'] : 'title';
$sortDir = ($_GET['dir']  ?? '') === 'desc' ? 'DESC' : 'ASC';
$perPage = 9999;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$conds  = [];
$params = [];
if ($search !== '') {
  $conds[] = "(title LIKE ? OR composer LIKE ? OR arranger LIKE ? OR genre LIKE ? OR owner LIKE ?)";
  $params  = array_merge($params, ["%$search%","%$search%","%$search%","%$search%","%$search%"]);
}

$where   = $conds ? "WHERE ".implode(" AND ", $conds) : "";
if ($sortBy === 'composer') {
  $orderBy = "composer IS NULL OR composer='', composer $sortDir, title ASC";
} elseif ($sortBy === 'arranger') {
  $orderBy = "arranger IS NULL OR arranger='', arranger $sortDir, title ASC";
} elseif ($sortBy === 'genre') {
  $orderBy = "genre IS NULL OR genre='', genre $sortDir, title ASC";
} elseif ($sortBy === 'owner') {
  $orderBy = "owner IS NULL OR owner='', owner $sortDir, title ASC";
} elseif ($sortBy === 'scan') {
  $orderBy = "(has_scan + has_score_scan) $sortDir, title ASC";
} elseif ($sortBy === 'binder') {
  $orderBy = $sortDir === 'DESC' ? "(binder IS NOT NULL AND binder != '') DESC, title ASC" : "(binder IS NULL OR binder = '') ASC, title ASC";
} elseif ($sortBy === 'difficulty') {
  $orderBy = "difficulty IS NULL, difficulty $sortDir, title ASC";
} elseif ($sortBy === 'duration') {
  // Dauer als Sekunden parsen: "6:30" oder "6:30" oder "6" → Minuten*60+Sekunden
  $orderBy = "(CASE WHEN duration IS NULL OR duration = '' THEN 99999
    WHEN duration REGEXP '^[0-9]+[\':][0-9]+' THEN
      CAST(SUBSTRING_INDEX(REPLACE(duration, '\'', ':'), ':', 1) AS UNSIGNED)*60 +
      CAST(SUBSTRING_INDEX(REPLACE(duration, '\'', ':'), ':', -1) AS UNSIGNED)
    ELSE CAST(duration AS UNSIGNED)*60 END) $sortDir, title ASC";
} else {
  $orderBy = "title $sortDir";
}

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM pieces $where");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = max(1, (int)ceil($total / $perPage));

$stmt = $pdo->prepare("SELECT * FROM pieces $where ORDER BY $orderBy LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$pieces = $stmt->fetchAll();

$activeSongPieceIds = array_column(
  $pdo->query("SELECT piece_id FROM songs WHERE piece_id IS NOT NULL AND is_active=1")->fetchAll(),
  'piece_id'
);

sv_header('Admin – Bibliothek', $admin);

function diffPill(mixed $d): string {
  if ($d === null || $d === '') return '<span class="small" style="color:#bbb">–</span>';
  $d = (float)$d;
  if ($d <= 2)     $style = 'background:var(--green-light);color:var(--green);border-color:var(--green-mid)';
  elseif ($d <= 4) $style = 'background:#fff8e1;color:#b8860b;border-color:rgba(184,134,11,.3)';
  else             $style = 'background:var(--red-soft);color:var(--red);border-color:rgba(193,9,15,.3)';
  return '<span class="badge" style="'.$style.'">'.number_format($d,1).'</span>';
}
?>

<div class="page-header">
  <div>
    <h2>Notenbibliothek</h2>
    <div class="muted"><?=h($total)?> Stücke im Archiv</div>
  </div>
  <div class="row">
    <div class="btn-group">
      <button class="btn" id="btn-view-table"    onclick="setView('table')"    title="Tabelle">☰ Tabelle</button>
      <button class="btn" id="btn-view-cards"    onclick="setView('cards')"    title="Karten">⊞ Karten</button>
      <button class="btn" id="btn-view-detail"   onclick="setView('detail')"   title="Liste + Detail">⊟ Detail</button>
      <button class="btn" id="btn-view-accordion" onclick="setView('accordion')" title="Akkordion">☷ Akkordion</button>
    </div>
    <a class="btn primary" href="#" data-open-dialog="dialog-new-piece">+ Neues Stück</a>
    <a class="btn" href="<?=h($base)?>/admin/bibliothek_merge.php">🔀 Zusammenführen</a>
    <a class="btn" href="<?=h($base)?>/admin/bibliothek_import.php">📥 Import / Export</a>
    <a class="btn" href="<?=h($base)?>/admin/">← Admin</a>
  </div>
</div>

<!-- Suche & Filter -->
<div class="card" style="margin-bottom:12px">
  <form method="get" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <label style="flex:1;min-width:200px">Suche<br>
      <input class="input" type="text" name="q" value="<?=h($search)?>"
             placeholder="Titel, Komponist, Arrangeur, Genre, Eigentümer…" style="width:100%;margin-top:5px">
    </label>
    <div style="display:flex;gap:8px;padding-bottom:1px">
      <button class="btn primary" type="submit">Suchen</button>
      <a class="btn" href="bibliothek.php">Reset</a>
    </div>
  </form>
  <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-top:10px;padding-top:10px;border-top:1px solid var(--border)">
    <span style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--muted)">Spalten</span>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="bib-col-composer" onchange="bibCol('composer',this.checked);bibCol('arranger',this.checked)" checked> Komponist / Arrangeur</label>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="bib-col-genre"       onchange="bibCol('genre',this.checked)"       checked> Genre</label>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="bib-col-difficulty"  onchange="bibCol('difficulty',this.checked)"  checked> Grad</label>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="bib-col-duration"    onchange="bibCol('duration',this.checked)"    checked> Länge</label>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="bib-col-owner"       onchange="bibCol('owner',this.checked)"       checked> Eigentümer</label>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="bib-col-scan"        onchange="bibCol('scan',this.checked)"        checked> Scan</label>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="bib-col-binder"      onchange="bibCol('binder',this.checked)"      checked> Mappe</label>
    <span class="small" style="margin-left:auto"><?=h($total)?> Treffer</span>
  </div>
</div>

<!-- TABELLE -->
<div id="view-table" class="view-panel">
<div class="card">
  <div class="table-scroll">
    <table>
      <thead>
        <tr>
          <?php
          function sortTh(string $col, string $label, string $cur, string $dir, string $colClass=''): string {
            $active = $cur===$col;
            $nd = ($active && $dir==='ASC') ? 'desc' : 'asc';
            $icon = $active ? ($dir==='ASC'?' ↑':' ↓') : '';
            $qs = http_build_query(array_filter(['q'=>$_GET['q']??'','sort'=>$col,'dir'=>$nd]));
            $style = ($active?'color:var(--red);':'').'cursor:pointer;white-space:nowrap;user-select:none';
            $cc = $colClass ? ' class="'.$colClass.'"' : '';
            return '<th'.$cc.' style="'.$style.'"><a href="?'.$qs.'" style="text-decoration:none;color:inherit">'.$label.$icon.'</a></th>';
          }
          echo sortTh('title',      'Titel',          $sortBy,$sortDir);
          // Kombinierter Komponist/Arrangeur-Kopf
          $icK = $sortBy==='composer' ? ($sortDir==='ASC'?' ↑':' ↓') : '';
          $icA = $sortBy==='arranger' ? ($sortDir==='ASC'?' ↑':' ↓') : '';
          $ndK = ($sortBy==='composer'&&$sortDir==='ASC')?'desc':'asc';
          $ndA = ($sortBy==='arranger'&&$sortDir==='ASC')?'desc':'asc';
          $qK  = http_build_query(array_filter(['q'=>$_GET['q']??'','sort'=>'composer','dir'=>$ndK]));
          $qA  = http_build_query(array_filter(['q'=>$_GET['q']??'','sort'=>'arranger','dir'=>$ndA]));
          $stK = ($sortBy==='composer'?'color:var(--red)':'color:inherit').';cursor:pointer;user-select:none;display:block';
          $stA = ($sortBy==='arranger'?'color:var(--red)':'color:var(--muted)').';cursor:pointer;user-select:none;display:block;font-size:12px';
          echo '<th class="bib-col bib-col-composer bib-col-arranger" style="white-space:nowrap"><a href="?'.$qK.'" style="text-decoration:none;'.$stK.'">Komponist'.$icK.'</a><a href="?'.$qA.'" style="text-decoration:none;font-size:12px;'.$stA.'">Arrangeur'.$icA.'</a></th>';
          echo sortTh('genre',      'Genre',          $sortBy,$sortDir,'bib-col bib-col-genre');
          echo sortTh('difficulty', 'Grad',  $sortBy,$sortDir,'bib-col bib-col-difficulty');
          echo sortTh('duration',   'Länge',          $sortBy,$sortDir,'bib-col bib-col-duration');
          echo sortTh('owner',      'Eigentümer',     $sortBy,$sortDir,'bib-col bib-col-owner');
          echo sortTh('scan',       'Scan',           $sortBy,$sortDir,'bib-col bib-col-scan');
          echo sortTh('binder',     'Mappe',          $sortBy,$sortDir,'bib-col bib-col-binder');
          ?>
          <th style="width:44px"></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($pieces as $p): ?>
        <tr>
          <td style="min-width:180px"><strong><?=h($p['title'])?></strong><?php if(!empty($p['querverweis'])): ?> <span class="small" style="color:var(--muted);font-weight:400">/ <?=h($p['querverweis'])?></span><?php endif; ?>
            <?php if(!empty($p['youtube_url'])): ?><div><a class="song-link" href="<?=h($p['youtube_url'])?>" target="_blank" rel="noopener">▶ YouTube öffnen</a></div><?php endif; ?>
            <?php if(!empty($p['publisher'])): ?><div class="small"><?=h($p['publisher'])?></div><?php endif; ?>
            <?php if(in_array((int)$p['id'],$activeSongPieceIds)): ?><div><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid);font-size:11px">aktiv</span></div><?php endif; ?>
          </td>
          <td class="small bib-col bib-col-composer bib-col-arranger" style="min-width:80px;max-width:130px">
            <?=h($p['composer'] ?? '–')?>
            <?php if(!empty($p['arranger'])): ?><div style="color:var(--muted);font-size:12px">Arr. <?=h($p['arranger'])?></div><?php endif; ?>
          </td>
          <td class="small bib-col bib-col-genre" style="white-space:nowrap"><?=h($p['genre'] ?? '–')?></td>
          <td class="bib-col bib-col-difficulty" style="white-space:nowrap"><?=diffPill($p['difficulty'])?></td>
          <td class="small bib-col bib-col-duration" style="white-space:nowrap"><?=h($p['duration'] ?? '–')?></td>
          <td class="small bib-col bib-col-owner" style="white-space:nowrap">
            <?php if($p['owner']=== 'MS Hi'): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid);font-weight:700">MS Hi</span>
            <?php else: ?><?=h($p['owner'] ?? '–')?><?php endif; ?>
          </td>
          <td class="small bib-col bib-col-scan" style="white-space:nowrap">
            <div><?= $p['has_scan'] ? '<span style="color:var(--green)">✓ St.</span>' : '<span style="color:#ccc">✗ St.</span>' ?></div>
            <div><?= $p['has_score_scan'] ? '<span style="color:var(--green)">✓ Pa.</span>' : '<span style="color:#ccc">✗ Pa.</span>' ?></div>
          </td>
          <td class="bib-col bib-col-binder" style="white-space:nowrap;text-align:center"><?= !empty($p['binder']) ? '<span style="color:var(--green);font-size:16px">✓</span>' : '<span style="color:#ddd">–</span>' ?></td>
          <td style="white-space:nowrap;text-align:center">
            <div style="position:relative;display:inline-block">
              <button class="btn" style="padding:4px 10px;font-size:16px;line-height:1" onclick="toggleMenu(this)">⋯</button>
              <div class="piece-menu" style="display:none;position:fixed;background:#fff;border:1.5px solid var(--border);border-radius:12px;box-shadow:0 4px 16px rgba(0,0,0,.1);z-index:9999;min-width:180px;overflow:hidden">
                <button class="piece-menu-item" type="button" data-open-dialog="dialog-edit-<?=h($p['id'])?>" onclick="closeMenus()">✏️ Bearbeiten</button>
                <?php if(!in_array((int)$p['id'],$activeSongPieceIds)): ?>
                <form method="post"><input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>"><input type="hidden" name="action" value="to_song"><input type="hidden" name="pid" value="<?=h($p['id'])?>">
                  <button class="piece-menu-item" type="submit">🎵 Zur Abstimmung</button>
                </form>
                <?php else: ?><div class="piece-menu-item" style="opacity:.5;cursor:default">🎵 Bereits aktiv</div><?php endif; ?>
                <form method="post" onsubmit="return confirm('Stück wirklich löschen?')">
                  <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="pid" value="<?=h($p['id'])?>">
                  <button class="piece-menu-item" type="submit" style="color:var(--red)">🗑 Löschen</button>
                </form>
              </div>
            </div>
          </td>
        </tr>

        <dialog id="dialog-edit-<?=h($p['id'])?>" class="sv-dialog">
          <div class="sv-dialog__panel" tabindex="-1">
            <div class="sv-dialog__head">
              <div>
                <div class="sv-dialog__title">Stück bearbeiten</div>
                <div class="sv-dialog__sub"><?=h($p['title'])?></div>
              </div>
              <button class="sv-dialog__close" type="button" data-close-dialog aria-label="Schließen">✕</button>
            </div>
            <div class="sv-dialog__section">
              <?= pieceForm($p, 'update') ?>
            </div>
          </div>
        </dialog>
      <?php endforeach; ?>
      <?php if(!$pieces): ?>
        <tr><td colspan="8" class="small"><?= $search ? 'Keine Treffer für „'.h($search).'".' : 'Noch keine Stücke im Archiv. Stücke manuell anlegen oder per Import laden.' ?></td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if($pages > 1): ?>
  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:16px;align-items:center">
    <?php for($i=1; $i<=$pages; $i++): ?>
      <?php
        $qParams = array_filter([
          'q'        => $search,
          'composer' => $fComposer,
          'genre'    => $fGenre,
          'owner'    => $fOwner,
          'diff_min' => $fDiffMin !== null ? $fDiffMin : '',
          'diff_max' => $fDiffMax !== null ? $fDiffMax : '',
          'binder'   => $fBinder,
          'sort'     => $sortBy !== 'title' ? $sortBy : '',
          'dir'      => $sortDir === 'DESC' ? 'desc' : '',
        ]);
        $qStr = $qParams ? '&' . http_build_query($qParams) : '';
      ?>
      <a class="btn<?= $i===$page?' primary':'' ?>" href="?page=<?=$i?><?=$qStr?>"><?=$i?></a>
    <?php endfor; ?>
    <span class="small">Seite <?=$page?> von <?=$pages?> (<?=$total?> Stücke)</span>
  </div>
  <?php endif; ?>
</div>
</div><!-- /view-table -->

<!-- KARTEN -->
<div id="view-cards" class="view-panel" style="display:none">
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px">
  <?php foreach ($pieces as $p): ?>
    <div class="card" style="padding:14px;display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;font-size:14px;line-height:1.3"><?=h($p['title'])?></div>
          <?php if(!empty($p['composer'])||!empty($p['arranger'])): ?><div class="small" style="color:var(--muted);margin-top:2px"><?= implode(' · ', array_filter([h($p['composer']??''), $p['arranger'] ? 'Arr. '.h($p['arranger']) : ''])) ?></div><?php endif; ?>
          <?php if(!empty($p['publisher'])): ?><div class="small" style="color:var(--muted)"><?=h($p['publisher'])?></div><?php endif; ?>
        </div>
        <?=diffPill($p['difficulty'])?>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:5px">
        <?php if(!empty($p['duration'])): ?><span class="badge">⏱ <?=h($p['duration'])?></span><?php endif; ?>
        <?php if(!empty($p['genre'])): ?><span class="badge"><?=h($p['genre'])?></span><?php endif; ?>
        <?php if(!empty($p['owner'])): ?><?php if($p['owner']==='MS Hi'): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid);font-weight:700">👤 MS Hi</span><?php else: ?><span class="badge" style="background:#f0ece6">👤 <?=h($p['owner'])?></span><?php endif; ?><?php endif; ?>
        <?php if($p['has_scan']): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid)">✓ Stimmen</span><?php endif; ?>
        <?php if($p['has_score_scan']): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid)">✓ Partitur</span><?php endif; ?>
        <?php if(!empty($p['binder'])): ?><span class="badge">📁 Mappe</span><?php endif; ?>
      </div>
      <?php if(!empty($p['youtube_url'])): ?><a class="song-link" href="<?=h($p['youtube_url'])?>" target="_blank" rel="noopener">▶ YouTube öffnen</a><?php endif; ?>
      <div style="display:flex;gap:6px;margin-top:auto;padding-top:8px;border-top:1px solid var(--border)">
        <button class="btn primary" style="flex:1;font-size:12px" type="button" data-open-dialog="dialog-edit-<?=h($p['id'])?>">✏️ Bearb.</button>
        <?php if(!in_array((int)$p['id'],$activeSongPieceIds)): ?>
          <form method="post" style="flex:1"><input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>"><input type="hidden" name="action" value="to_song"><input type="hidden" name="pid" value="<?=h($p['id'])?>">
            <button class="btn" type="submit" style="width:100%;font-size:12px">→ Abstimmung</button>
          </form>
        <?php else: ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid);align-self:center">aktiv</span><?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if(!$pieces): ?><div class="card small"><?= $search ? 'Keine Treffer.' : 'Noch keine Stücke.' ?></div><?php endif; ?>
  </div>
</div><!-- /view-cards -->

<!-- DETAIL -->
<div id="view-detail" class="view-panel" style="display:none">
  <div style="display:grid;grid-template-columns:340px 1fr;gap:12px;align-items:start">
    <div class="card" style="padding:0;overflow:hidden">
      <?php foreach ($pieces as $p): ?>
      <div class="detail-list-row" data-id="<?=h($p['id'])?>" onclick="showDetail(this)"
           style="padding:10px 14px;border-bottom:1px solid var(--border);cursor:pointer">
        <div style="font-weight:600;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=h($p['title'])?></div>
        <div class="small" style="color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
          <?= implode(' · ', array_filter([h($p['composer']??''), $p['arranger'] ? 'Arr. '.h($p['arranger']) : ''])) ?: '–' ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div id="detail-panel" class="card" style="min-height:300px">
      <div style="display:flex;align-items:center;justify-content:center;height:200px;color:var(--muted);font-size:14px">← Stück auswählen</div>
    </div>
  </div>
  <div id="detail-data" style="display:none">
  <?php foreach ($pieces as $p): ?>
    <div data-id="<?=h($p['id'])?>" data-title="<?=h($p['title'])?>"
         data-composer="<?=h($p['composer']??'')?>" data-arranger="<?=h($p['arranger']??'')?>"
         data-publisher="<?=h($p['publisher']??'')?>" data-duration="<?=h($p['duration']??'')?>"
         data-genre="<?=h($p['genre']??'')?>" data-difficulty="<?=h($p['difficulty']??'')?>"
         data-owner="<?=h($p['owner']??'')?>" data-youtube="<?=h($p['youtube_url']??'')?>"
         data-info="<?=h($p['info']??'')?>"
         data-scan="<?=$p['has_scan']?'1':'0'?>" data-scanscore="<?=$p['has_score_scan']?'1':'0'?>"
         data-original="<?=$p['has_original_score']?'1':'0'?>" data-binder="<?=!empty($p['binder'])?'1':'0'?>"
         data-active="<?=in_array((int)$p['id'],$activeSongPieceIds)?'1':'0'?>"></div>
  <?php endforeach; ?>
  </div>
</div><!-- /view-detail -->

<!-- AKKORDION -->
<div id="view-accordion" class="view-panel" style="display:none">
  <div class="card" style="padding:0;overflow:hidden">
    <?php foreach ($pieces as $p): ?>
    <details class="acc-item" style="border-bottom:1px solid var(--border)">
      <summary style="padding:12px 16px;cursor:pointer;list-style:none;display:flex;align-items:center;gap:12px;user-select:none">
        <span class="acc-arrow" style="font-size:12px;color:var(--muted);flex-shrink:0;transition:transform .2s;display:inline-block">▶</span>
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?=h($p['title'])?></div>
          <div class="small" style="color:var(--muted)"><?= implode(' · ', array_filter([h($p['composer']??''), $p['arranger'] ? 'Arr. '.h($p['arranger']) : ''])) ?: '–' ?></div>
        </div>
        <div style="display:flex;gap:6px;align-items:center;flex-shrink:0">
          <?=diffPill($p['difficulty'])?>
          <?php if(!empty($p['duration'])): ?><span class="badge">⏱ <?=h($p['duration'])?></span><?php endif; ?>
          <?php if($p['has_scan']||$p['has_score_scan']): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid)">✓ Scan</span><?php endif; ?>
          <?php if(in_array((int)$p['id'],$activeSongPieceIds)): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid)">aktiv</span><?php endif; ?>
        </div>
      </summary>
      <div style="padding:0 16px 14px 42px;border-top:1px solid var(--border);background:#fdfcfa">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:6px 20px;margin-top:12px;font-size:13px">
          <?php if(!empty($p['composer'])): ?><div><span style="color:var(--muted)">Komponist:</span> <?=h($p['composer'])?></div><?php endif; ?>
          <?php if(!empty($p['arranger'])): ?><div><span style="color:var(--muted)">Arrangeur:</span> <?=h($p['arranger'])?></div><?php endif; ?>
          <?php if(!empty($p['publisher'])): ?><div><span style="color:var(--muted)">Verlag:</span> <?=h($p['publisher'])?></div><?php endif; ?>
          <?php if(!empty($p['genre'])): ?><div><span style="color:var(--muted)">Genre:</span> <?=h($p['genre'])?></div><?php endif; ?>
          <?php if(!empty($p['owner'])): ?><div><span style="color:var(--muted)">Eigentümer:</span> <?php if($p['owner']==='MS Hi'): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid);font-weight:700">MS Hi</span><?php else: ?><?=h($p['owner'])?><?php endif; ?></div><?php endif; ?>
        </div>
        <?php if(!empty($p['info'])): ?><div style="margin-top:8px;font-size:13px;color:var(--muted)"><?=h($p['info'])?></div><?php endif; ?>
        <div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:10px">
          <?php if($p['has_scan']): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid)">✓ Stimmen</span><?php endif; ?>
          <?php if($p['has_score_scan']): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid)">✓ Partitur</span><?php endif; ?>
          <?php if($p['has_original_score']): ?><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid)">✓ Original</span><?php endif; ?>
          <?php if(!empty($p['binder'])): ?><span class="badge">📁 Mappe</span><?php endif; ?>
        </div>
        <?php if(!empty($p['youtube_url'])): ?><div style="margin-top:8px"><a class="song-link" href="<?=h($p['youtube_url'])?>" target="_blank" rel="noopener">▶ YouTube öffnen</a></div><?php endif; ?>
        <div style="display:flex;gap:8px;margin-top:12px;padding-top:10px;border-top:1px solid var(--border)">
          <button class="btn primary" type="button" data-open-dialog="dialog-edit-<?=h($p['id'])?>">✏️ Bearbeiten</button>
          <?php if(!in_array((int)$p['id'],$activeSongPieceIds)): ?>
            <form method="post" style="display:contents"><input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>"><input type="hidden" name="action" value="to_song"><input type="hidden" name="pid" value="<?=h($p['id'])?>">
              <button class="btn" type="submit">🎵 Zur Abstimmung</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </details>
    <?php endforeach; ?>
  </div>
</div><!-- /view-accordion -->

<!-- Neues Stück Dialog -->
<dialog id="dialog-new-piece" class="sv-dialog">
  <div class="sv-dialog__panel" tabindex="-1">
    <div class="sv-dialog__head">
      <div class="sv-dialog__title">Neues Stück anlegen</div>
      <button class="sv-dialog__close" type="button" data-close-dialog aria-label="Schließen">✕</button>
    </div>
    <div class="sv-dialog__section">
      <?= pieceForm(null, 'create') ?>
    </div>
  </div>
</dialog>

<?php
?>

<script>
(function svDialogInit(){
  document.addEventListener('click', function(e){
    var openBtn = e.target.closest('[data-open-dialog]');
    if(openBtn){
      var id = openBtn.getAttribute('data-open-dialog');
      var dlg = document.getElementById(id);
      if(dlg){ dlg.showModal(); var p=dlg.querySelector('.sv-dialog__panel'); if(p) p.focus(); }
      return;
    }
    var closeBtn = e.target.closest('[data-close-dialog]');
    if(closeBtn){
      var dlg = closeBtn.closest('dialog');
      if(dlg){
        // Reset all inputs to original values before closing
        dlg.querySelectorAll('input:not([type=hidden]), textarea, select').forEach(function(el){
          el.value = el.defaultValue;
          if(el.type==='checkbox') el.checked = el.defaultChecked;
        });
        dlg.close();
      }
      return;
    }
  });
  document.querySelectorAll('dialog.sv-dialog').forEach(function(dlg){
    // backdrop click intentionally disabled
  });
})();
</script>


<script>
function buildSearchQuery(form, type) {
  var title    = ((form.querySelector('[name="title"]')    || {}).value || '').trim();
  var composer = ((form.querySelector('[name="composer"]') || {}).value || '').trim();
  var arranger = ((form.querySelector('[name="arranger"]') || {}).value || '').trim();
  if (!title) return '';
  var parts = [title];
  if (arranger) parts.push(arranger);
  else if (composer) parts.push(composer);
  if (type === 'google') parts.push('Blasorchester OR "concert band"');
  return parts.join(' ');
}
function openSearchWindow(btn, type) {
  // Suche das nächste form oder dialog-panel
  var container = btn.closest('form') || btn.closest('.sv-dialog__section') || btn.closest('dialog');
  if (!container) return;
  var title    = ((container.querySelector('[name="title"]')    || {}).value || '').trim();
  var composer = ((container.querySelector('[name="composer"]') || {}).value || '').trim();
  var arranger = ((container.querySelector('[name="arranger"]') || {}).value || '').trim();
  if (!title) { alert('Bitte zuerst einen Titel eingeben.'); return; }
  var parts = [title];
  if (arranger) parts.push(arranger);
  else if (composer) parts.push(composer);
  if (type === 'google') parts.push('Blasorchester OR "concert band"');
  var query = parts.join(' ');
  var url = type === 'youtube'
    ? 'https://www.youtube.com/results?search_query=' + encodeURIComponent(query)
    : 'https://www.google.com/search?q=' + encodeURIComponent(query);
  var win = window.open(url, 'klangvotum_search_' + type, 'popup=yes,width=1280,height=900,left=80,top=60,resizable=yes,scrollbars=yes');
  if (!win) alert('Das Suchfenster wurde vom Browser blockiert. Bitte Popups für diese Seite erlauben.');
  else { try { win.focus(); } catch(e) {} }
}
</script>


<style>
.col-hidden { display:none!important; }
#btn-view-table.active,#btn-view-cards.active,#btn-view-detail.active,#btn-view-accordion.active { background:var(--red);color:#fff;border-color:var(--red); }
.piece-menu-item { display:block;width:100%;text-align:left;padding:9px 14px;font-size:13px;font-weight:600;background:none;border:none;cursor:pointer;color:var(--text);border-bottom:1px solid var(--border); }
.piece-menu-item:last-child { border-bottom:none; }
.piece-menu-item:hover { background:#faf8f5; }
.piece-menu form { margin:0; }
.detail-list-row:hover { background:#faf8f5; }
.detail-list-row.active-row { background:#f0f5e8!important;border-left:3px solid var(--green); }
.acc-item summary::-webkit-details-marker { display:none; }
.acc-item[open] .acc-arrow { transform:rotate(90deg); }
</style>
<style>
#btn-view-table.active,#btn-view-cards.active,#btn-view-detail.active,#btn-view-accordion.active { background:var(--red);color:#fff;border-color:var(--red); }
.piece-menu-item { display:block;width:100%;text-align:left;padding:9px 14px;font-size:13px;font-weight:600;background:none;border:none;cursor:pointer;color:var(--text);border-bottom:1px solid var(--border); }
.piece-menu-item:last-child { border-bottom:none; }
.piece-menu-item:hover { background:#faf8f5; }
.piece-menu form { margin:0; }
.detail-list-row:hover { background:#faf8f5; }
.detail-list-row.active-row { background:#f0f5e8!important;border-left:3px solid var(--green); }
.acc-item summary::-webkit-details-marker { display:none; }
.acc-item[open] .acc-arrow { transform:rotate(90deg); }
</style>
<script>
var currentView = localStorage.getItem('bib_view') || 'table';

function setView(v) {
  currentView = v;
  localStorage.setItem('bib_view', v);
  ['table','cards','detail','accordion'].forEach(function(n){
    var el = document.getElementById('view-'+n);
    if(el) el.style.display = n===v ? '' : 'none';
    var btn = document.getElementById('btn-view-'+n);
    if(btn) btn.classList.toggle('active', n===v);
  });
}

// Dropdown menu
function toggleMenu(btn) {
  var menu = btn.nextElementSibling;
  var isOpen = menu.style.display !== 'none';
  closeMenus();
  if (!isOpen) {
    menu.style.display = 'block';
    var r = btn.getBoundingClientRect();
    var mh = menu.offsetHeight || 120;
    menu.style.top  = (window.innerHeight - r.bottom < mh+8) ? (r.top-mh-4)+'px' : (r.bottom+4)+'px';
    menu.style.right = (window.innerWidth - r.right)+'px';
    setTimeout(function(){ document.addEventListener('click', closeOnOutside); }, 0);
  }
}
function closeMenus() {
  document.querySelectorAll('.piece-menu').forEach(function(m){ m.style.display='none'; });
  document.removeEventListener('click', closeOnOutside);
}
function closeOnOutside(e) {
  if (!e.target.closest('.piece-menu') && !e.target.closest('[onclick*="toggleMenu"]')) closeMenus();
}

// AJAX edit dialog
document.addEventListener('click', function(e){
  var openBtn = e.target.closest('[data-open-dialog]');
  if(openBtn){ var d=document.getElementById(openBtn.getAttribute('data-open-dialog')); if(d){ d.showModal(); var p=d.querySelector('.sv-dialog__panel'); if(p) p.focus(); } return; }

  var closeBtn = e.target.closest('[data-close-dialog]');
  if(closeBtn){ var d=closeBtn.closest('dialog'); if(d){ d.close(); document.body.style.overflow=''; } }
});

// Detail view
function showDetail(row) {
  document.querySelectorAll('.detail-list-row').forEach(function(r){ r.classList.remove('active-row'); });
  row.classList.add('active-row');
  var id = row.dataset.id;
  var d = document.querySelector('#detail-data [data-id="'+id+'"]');
  if(!d) return;
  var diff = d.dataset.difficulty;
  var diffHtml = '';
  if(diff){ var dv=parseFloat(diff),dc=dv<=2?'background:var(--green-light);color:var(--green);border-color:var(--green-mid)':dv<=4?'background:#fff8e1;color:#b8860b;border-color:rgba(184,134,11,.3)':'background:var(--red-soft);color:var(--red);border-color:rgba(193,9,15,.3)'; diffHtml='<span class="badge" style="'+dc+'">'+dv.toFixed(1)+'</span>'; }
  var fields=[['Komponist',d.dataset.composer],['Arrangeur',d.dataset.arranger],['Verlag',d.dataset.publisher],['Dauer',d.dataset.duration],['Genre',d.dataset.genre],['Eigentümer',d.dataset.owner],['Info',d.dataset.info]].filter(function(f){return f[1];});
  var toggles=[];
  if(d.dataset.scan==='1') toggles.push('✓ Stimmen');
  if(d.dataset.scanscore==='1') toggles.push('✓ Partitur');
  if(d.dataset.original==='1') toggles.push('✓ Original');
  if(d.dataset.binder==='1') toggles.push('📁 Mappe');
  var html='<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:14px"><div><div style="font-weight:700;font-size:16px">'+escH(d.dataset.title)+'</div>'+(d.dataset.composer||d.dataset.arranger?'<div class="small" style="color:var(--muted)">'+escH([d.dataset.composer,d.dataset.arranger?'Arr. '+d.dataset.arranger:''].filter(Boolean).join(' · '))+'</div>':'')+'</div>'+diffHtml+'</div>';
  if(fields.length){html+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 16px;margin-bottom:12px">';fields.forEach(function(f){html+='<div class="small"><span style="color:var(--muted)">'+f[0]+':</span> '+escH(f[1])+'</div>';});html+='</div>';}
  if(toggles.length) html+='<div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:10px">'+toggles.map(function(t){return'<span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid)">'+t+'</span>';}).join('')+'</div>';
  if(d.dataset.youtube) html+='<div style="margin-bottom:10px"><a class="song-link" href="'+escH(d.dataset.youtube)+'" target="_blank" rel="noopener">▶ YouTube öffnen</a></div>';
  html+='<div style="display:flex;gap:8px;padding-top:12px;border-top:1px solid var(--border)"><button class="btn primary" type="button" data-open-dialog="dialog-edit-'+id+'">Bearbeiten</button>'+(d.dataset.active!=='1'?'<form method="post" style="display:contents"><input type="hidden" name="csrf" value=""><input type="hidden" name="action" value="to_song"><input type="hidden" name="pid" value="'+id+'"><button class="btn" type="submit">→ Abstimmung</button></form>':'')+'</div>';
  document.getElementById('detail-panel').innerHTML = html;
  // Re-fill CSRF
  var csrfMaster = document.querySelector('input[name="csrf"]');
  document.querySelectorAll('#detail-panel input[name="csrf"]').forEach(function(i){ if(csrfMaster) i.value=csrfMaster.value; });
}

function escH(s){ var d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }

document.addEventListener('DOMContentLoaded', function(){ setView(currentView); });
</script>

<script>
function bibCol(name, show) {
  document.querySelectorAll('.bib-col-'+name).forEach(function(el){
    el.classList.toggle('col-hidden', !show);
  });
  var p = JSON.parse(localStorage.getItem('bib_cols')||'{}');
  p[name]=show; localStorage.setItem('bib_cols', JSON.stringify(p));
}
</script>
<?php sv_footer(); ?>
