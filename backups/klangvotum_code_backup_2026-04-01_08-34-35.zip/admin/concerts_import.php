<?php
// ── Import Auftrittsdaten aus Excel-Auswertung ────────────────────────────────
// Einmalig aufrufen: importiert 73 Konzerte mit Programm aus der Bibliotheks-Excel
// DANACH LÖSCHEN!
require_once __DIR__ . '/../lib/auth.php';
sv_require_admin();
$pdo = sv_pdo();

$data = json_decode(file_get_contents(__DIR__ . '/../lib/concerts_import.json'), true);
if (!$data) die('concerts_import.json nicht gefunden oder ungültig.');

$concertCount = 0;
$pieceCount   = 0;
$skipCount    = 0;
$log = [];

// Jahreskonzert-Monate schätzen (JaKo = ~Mai, WK = ~Oktober, MSW = ~März)
function guessMonth(string $name): string {
    $name = strtolower($name);
    if (str_contains($name, 'jako') || str_contains($name, 'jahreskonzert')) return '-05-01';
    if (str_contains($name, 'wk') || str_contains($name, 'weihnacht')) return '-12-01';
    if (str_contains($name, 'msw') || str_contains($name, 'musikschul') || str_contains($name, 'frühling')) return '-03-01';
    if (str_contains($name, 'zoom')) return '-01-01';
    return '-06-01';
}

foreach ($data as $concert) {
    $name  = $concert['name'];
    $year  = $concert['year'];
    $pieces = $concert['pieces'];

    // Datum schätzen
    $date = null;
    if ($year) {
        $date = $year . guessMonth($name);
    }

    // Konzert anlegen (skip wenn schon vorhanden)
    $existing = $pdo->prepare("SELECT id FROM concerts WHERE name=?");
    $existing->execute([$name]);
    $cid = $existing->fetchColumn();

    if (!$cid) {
        try {
            $pdo->prepare("INSERT INTO concerts (name, date, notes) VALUES (?,?,?)")
                ->execute([$name, $date, 'Importiert aus Bibliotheksverzeichnis']);
            $cid = (int)$pdo->lastInsertId();
            $concertCount++;
            $log[] = "✓ Konzert: $name ($date)";
        } catch (Throwable $e) {
            $log[] = "✗ Fehler bei $name: " . $e->getMessage();
            continue;
        }
    } else {
        $log[] = "~ Konzert vorhanden, ergänze fehlende Stücke: $name";
        $skipCount++;
        // Kein continue — Stücke trotzdem ergänzen!
    }

    // Stücke zuordnen
    foreach ($pieces as $p) {
        $title = $p['title'];
        $pos   = $p['position'];

        // Stück suchen - zuerst exakt, dann ersten Teil bei "/" trennen
        $sp = $pdo->prepare("SELECT id FROM pieces WHERE title=?");
        $sp->execute([$title]);
        $pid = $sp->fetchColumn();

        if (!$pid && str_contains($title, '/')) {
          // Versuche nur den ersten Teil (vor dem /)
          $firstPart = trim(explode('/', $title)[0]);
          $sp->execute([$firstPart]);
          $pid = $sp->fetchColumn();
        }

        if (!$pid) {
          // LIKE-Suche als Fallback
          $sp2 = $pdo->prepare("SELECT id FROM pieces WHERE title LIKE ?");
          $sp2->execute([$title . '%']);
          $pid = $sp2->fetchColumn();
        }

        if ($pid) {
            try {
                $pdo->prepare("INSERT IGNORE INTO concert_pieces (concert_id, piece_id, position) VALUES (?,?,?)")
                    ->execute([$cid, $pid, $pos]);
                $pieceCount++;
            } catch (Throwable $e) {}
        } else {
            $log[] = "  ⚠ Stück nicht gefunden: '$title'";
        }
    }
}

?><!DOCTYPE html>
<html lang="de">
<head><meta charset="UTF-8"><title>Import</title>
<style>body{font-family:sans-serif;padding:20px;max-width:800px} .ok{color:green} .warn{color:orange} .err{color:red}</style>
</head>
<body>
<h2>Konzert-Import abgeschlossen</h2>
<p><strong><?=$concertCount?></strong> Konzerte importiert &nbsp;·&nbsp;
   <strong><?=$skipCount?></strong> übersprungen &nbsp;·&nbsp;
   <strong><?=$pieceCount?></strong> Stückverknüpfungen erstellt</p>
<a href="concerts.php">→ Zur Chronik</a>
<hr>
<pre style="font-size:12px;max-height:500px;overflow:auto;background:#f5f5f5;padding:12px"><?=htmlspecialchars(implode("\n", $log))?></pre>
<p style="color:red"><strong>Bitte diese Datei jetzt löschen!</strong></p>
</body></html>
