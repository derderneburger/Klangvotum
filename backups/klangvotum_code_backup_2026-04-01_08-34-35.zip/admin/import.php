<?php
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/layout.php';

$admin = sv_require_admin();
$pdo = sv_pdo();

function detect_delim(string $line): string {
  return (substr_count($line, ';') >= substr_count($line, ',')) ? ';' : ',';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  sv_csrf_check();
  if (!isset($_FILES['csv']) || $_FILES['csv']['error'] !== UPLOAD_ERR_OK) {
    sv_flash_set('error', 'CSV Upload fehlgeschlagen.');
  } else {
    $content = file_get_contents($_FILES['csv']['tmp_name']);
    if ($content === false) {
      sv_flash_set('error', 'Konnte Datei nicht lesen.');
    } else {
      $enc = mb_detect_encoding($content, ['UTF-8','ISO-8859-1','Windows-1252'], true);
      if ($enc && $enc !== 'UTF-8') $content = mb_convert_encoding($content, 'UTF-8', $enc);
      $lines = preg_split("/\r\n|\n|\r/", $content);
      $lines = array_values(array_filter($lines, fn($l)=>trim($l)!==''));
      if (!$lines) {
        sv_flash_set('error', 'CSV ist leer.');
      } else {
        $delim = detect_delim($lines[0]);
        $inserted = 0; $skipped = 0;
        foreach ($lines as $idx => $line) {
          $row = str_getcsv($line, $delim);
          if (!$row || count($row) < 2) { $skipped++; continue; }
          $title = trim($row[0] ?? '');
          $url   = trim($row[1] ?? '');
          if ($idx === 0 && preg_match('/^(title|titel)$/i', $title)) continue;
          if ($title === '' || $url === '') { $skipped++; continue; }
          $pdo->prepare("INSERT INTO songs (title, youtube_url) VALUES (?, ?)")->execute([$title, $url]);
          $inserted++;
        }
        sv_log($admin['id'], 'csv_import', "inserted=$inserted skipped=$skipped");
        sv_flash_set('success', "Import fertig: $inserted eingefügt, $skipped übersprungen.");
      }
    }
  }
}

sv_header('Admin – CSV Import', $admin);
$base = sv_base_url();
?>

<div class="page-header">
  <div>
    <h2>CSV Import</h2>
    <div class="small">Mehrere Titel auf einmal importieren.</div>
  </div>
  <div class="row">
    <a class="btn" href="<?=h($base)?>/admin/songs.php">Titel</a>
    <a class="btn" href="<?=h($base)?>/admin/">← Admin</a>
  </div>
</div>

<div class="card">
  <h3>CSV-Datei hochladen</h3>
  <div class="small" style="margin-bottom:14px">
    Format: <code>Titel;YouTube-URL</code> (Semikolon oder Komma als Trennzeichen).<br>
    Eine optionale Kopfzeile (<code>title;youtube_url</code>) wird automatisch erkannt und übersprungen.
  </div>
  <form method="post" enctype="multipart/form-data" class="grid" style="gap:12px">
    <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
    <label style="display:block">
      CSV-Datei auswählen
      <input type="file" name="csv" accept=".csv,text/csv" required style="width:100%;margin-top:5px">
    </label>
    <div>
      <button class="btn primary" type="submit">Importieren</button>
    </div>
  </form>
</div>

<?php sv_footer(); ?>
