<?php
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/layout.php';

$admin = sv_require_admin();
$pdo   = sv_pdo();
$base  = sv_base_url();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  sv_csrf_check();
  $action = $_POST['action'] ?? '';

  if ($action === 'create' || $action === 'update') {
    $cid      = (int)($_POST['cid'] ?? 0);
    $name     = trim($_POST['name'] ?? '');
    $date     = trim($_POST['date'] ?? '') ?: null;
    $location = trim($_POST['location'] ?? '') ?: null;
    $notes    = trim($_POST['notes'] ?? '') ?: null;

    if ($name === '') {
      sv_flash_set('error', 'Name ist Pflichtfeld.');
    } else {
      try {
        if ($action === 'create') {
          $pdo->prepare("INSERT INTO concerts (name, date, location, notes) VALUES (?,?,?,?)")
            ->execute([$name, $date, $location, $notes]);
          sv_log($admin['id'], 'concert_create', $name);
          sv_flash_set('success', 'Auftritt angelegt.');
        } else {
          $pdo->prepare("UPDATE concerts SET name=?, date=?, location=?, notes=? WHERE id=?")
            ->execute([$name, $date, $location, $notes, $cid]);
          sv_log($admin['id'], 'concert_update', "cid=$cid");
          sv_flash_set('success', 'Auftritt aktualisiert.');
        }
      } catch (Throwable $e) {
        sv_flash_set('error', 'Fehler: ' . $e->getMessage());
      }
    }
    header('Location: ' . $base . '/admin/concerts.php');
    exit;

  } elseif ($action === 'delete') {
    $cid = (int)($_POST['cid'] ?? 0);
    if ($cid) {
      $pdo->prepare("DELETE FROM concerts WHERE id=?")->execute([$cid]);
      sv_log($admin['id'], 'concert_delete', "cid=$cid");
      sv_flash_set('success', 'Auftritt gelöscht.');
    }
    header('Location: ' . $base . '/admin/concerts.php');
    exit;

  } elseif ($action === 'add_piece') {
    $cid = (int)($_POST['cid'] ?? 0);
    $pid = (int)($_POST['pid'] ?? 0);
    if ($cid && $pid) {
      try {
        $mpStmt = $pdo->prepare("SELECT COALESCE(MAX(position),0) FROM concert_pieces WHERE concert_id=?");
        $mpStmt->execute([$cid]);
        $maxPos = (int)$mpStmt->fetchColumn();
        $pdo->prepare("INSERT IGNORE INTO concert_pieces (concert_id, piece_id, position) VALUES (?,?,?)")
          ->execute([$cid, $pid, $maxPos + 1]);
      } catch (Throwable $e) {}
    }
    header('Location: ' . $base . '/admin/concerts.php?cid=' . $cid);
    exit;

  } elseif ($action === 'remove_piece') {
    $cid = (int)($_POST['cid'] ?? 0);
    $pid = (int)($_POST['pid'] ?? 0);
    if ($cid && $pid) {
      $pdo->prepare("DELETE FROM concert_pieces WHERE concert_id=? AND piece_id=?")->execute([$cid, $pid]);
    }
    header('Location: ' . $base . '/admin/concerts.php?cid=' . $cid);
    exit;

  } elseif ($action === 'reorder') {
    $cid  = (int)($_POST['cid'] ?? 0);
    $pids = $_POST['pids'] ?? [];
    if ($cid && is_array($pids)) {
      $stmt = $pdo->prepare("UPDATE concert_pieces SET position=? WHERE concert_id=? AND piece_id=?");
      foreach ($pids as $pos => $pid) {
        $stmt->execute([$pos + 1, $cid, (int)$pid]);
      }
    }
    header('Content-Type: application/json');
    echo '{"ok":true}';
    exit;
  }
}

$search     = trim($_GET['q'] ?? '');
$selectedId = (int)($_GET['cid'] ?? 0);

$where  = $search ? "WHERE name LIKE ? OR location LIKE ?" : "";
$params = $search ? ["%$search%", "%$search%"] : [];
$stmt   = $pdo->prepare("SELECT * FROM concerts $where ORDER BY date DESC, id DESC");
$stmt->execute($params);
$concerts = $stmt->fetchAll();

$pieceCounts = [];
if ($concerts) {
  $ids = implode(',', array_map(function($row){ return (int)$row['id']; }, $concerts));
  $pcRows = $pdo->query("SELECT concert_id, COUNT(*) AS cnt FROM concert_pieces WHERE concert_id IN ($ids) GROUP BY concert_id")->fetchAll();
  foreach ($pcRows as $pc) $pieceCounts[(int)$pc['concert_id']] = (int)$pc['cnt'];
}

$selected  = null;
$selPieces = [];
$allPieces = $pdo->query("SELECT id, title, composer, arranger FROM pieces ORDER BY title ASC")->fetchAll();

if ($selectedId) {
  $s = $pdo->prepare("SELECT * FROM concerts WHERE id=?");
  $s->execute([$selectedId]);
  $selected = $s->fetch();
  if ($selected) {
    $sp = $pdo->prepare("SELECT cp.position, p.* FROM concert_pieces cp JOIN pieces p ON p.id=cp.piece_id WHERE cp.concert_id=? ORDER BY cp.position ASC, p.title ASC");
    $sp->execute([$selectedId]);
    $selPieces = $sp->fetchAll();
  }
}

function concertFormHtml(array $concert = null, string $action): string {
  $cid  = $concert ? (int)$concert['id'] : 0;
  $name = htmlspecialchars($concert['name'] ?? '', ENT_QUOTES);
  $date = htmlspecialchars($concert['date'] ?? '', ENT_QUOTES);
  $loc  = htmlspecialchars($concert['location'] ?? '', ENT_QUOTES);
  $note = htmlspecialchars($concert['notes'] ?? '', ENT_QUOTES);
  $csrf = htmlspecialchars(sv_csrf_token(), ENT_QUOTES);
  $btn  = $action === 'create' ? 'Anlegen' : 'Speichern';
  $cidF = $cid ? '<input type="hidden" name="cid" value="' . $cid . '">' : '';

  return '<form method="post" class="grid" style="gap:12px">'
    . '<input type="hidden" name="csrf" value="' . $csrf . '">'
    . '<input type="hidden" name="action" value="' . $action . '">'
    . $cidF
    . '<label style="grid-column:1/-1">Name *<br><input name="name" required value="' . $name . '" placeholder="z.B. Jahreskonzert 2024" style="width:100%;margin-top:5px"></label>'
    . '<label>Datum<br><input type="date" name="date" value="' . $date . '" style="width:100%;margin-top:5px"></label>'
    . '<label>Ort<br><input name="location" value="' . $loc . '" placeholder="z.B. Stadthalle Hildesheim" style="width:100%;margin-top:5px"></label>'
    . '<label style="grid-column:1/-1">Notizen<br><textarea name="notes" rows="3" style="width:100%;margin-top:5px">' . $note . '</textarea></label>'
    . '<div style="grid-column:1/-1;display:flex;gap:8px">'
    . '<button class="btn primary" type="submit">' . $btn . '</button>'
    . '<button class="btn" type="button" data-close-dialog>Abbrechen</button>'
    . '</div></form>';
}

$allPiecesJson = json_encode(array_map(function($ap){
  return [
    'id' => (int)$ap['id'],
    'title' => $ap['title'],
    'composer' => $ap['composer'] ?? ''
  ];
}, $allPieces), JSON_UNESCAPED_UNICODE);

sv_header('Admin – Auftrittchronik', $admin);
?>
<div class="page-header">
  <div>
    <h2>Auftrittchronik</h2>
    <div class="muted">Konzerte und Auftritte dokumentieren</div>
  </div>
  <div class="row">
    <a class="btn primary" href="#" data-open-dialog="dialog-new-concert">+ Neuer Auftritt</a>
    <?php if (file_exists(__DIR__ . '/concerts_import.php')): ?>
    <a class="btn" href="<?=h($base)?>/admin/concerts_import.php">📥 Excel importieren</a>
    <?php endif; ?>
    <a class="btn" href="<?=h($base)?>/admin/">← Admin</a>
  </div>
</div>

<div style="display:grid;grid-template-columns:360px 1fr;gap:16px;align-items:start">

  <div>
    <div class="card" style="margin-bottom:12px">
      <form method="get" style="display:flex;gap:8px">
        <input class="input" type="search" name="q" value="<?=h($search)?>" placeholder="Suche…" style="flex:1">
        <?php if ($selectedId): ?><input type="hidden" name="cid" value="<?=$selectedId?>"><?php endif; ?>
        <button class="btn primary" type="submit">Suchen</button>
        <?php if ($search): ?><a class="btn" href="concerts.php<?=$selectedId ? '?cid='.$selectedId : ''?>">✕</a><?php endif; ?>
      </form>
    </div>

    <div class="card" style="padding:0;overflow:hidden">
      <?php if (!$concerts): ?>
        <div style="padding:20px" class="small"><?= $search ? 'Keine Treffer.' : 'Noch keine Auftritte angelegt.' ?></div>
      <?php endif; ?>

      <?php foreach ($concerts as $c): ?>
        <?php $isActive = $selectedId === (int)$c['id']; ?>
        <div style="padding:12px 14px;border-bottom:1px solid var(--border);<?=$isActive ? 'background:#f0f5e8;border-left:3px solid var(--green)' : ''?>">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
            <a href="?cid=<?=h($c['id'])?><?=$search ? '&q='.urlencode($search) : ''?>" style="text-decoration:none;flex:1">
              <div style="font-weight:700;font-size:13px;color:var(--text)"><?=h($c['name'])?></div>
              <div class="small" style="color:var(--muted);margin-top:2px">
                <?php if ($c['date']): ?><span><?=date('d.m.Y', strtotime($c['date']))?></span><?php endif; ?>
                <?php if ($c['location']): ?><span> · <?=h($c['location'])?></span><?php endif; ?>
              </div>
            </a>
            <div style="position:relative;display:inline-block;flex-shrink:0">
              <button class="btn" style="padding:3px 8px;font-size:14px" onclick="toggleMenu(this)">⋯</button>
              <div class="piece-menu" style="display:none;position:fixed;background:#fff;border:1.5px solid var(--border);border-radius:12px;box-shadow:0 4px 16px rgba(0,0,0,.1);z-index:9999;min-width:160px;overflow:hidden">
                <button class="piece-menu-item" type="button" data-open-dialog="dialog-edit-<?=h($c['id'])?>" onclick="closeMenus()">✏️ Bearbeiten</button>
                <form method="post" onsubmit="return confirm('Auftritt löschen?')">
                  <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="cid" value="<?=h($c['id'])?>">
                  <button class="piece-menu-item" type="submit" style="color:var(--red)">🗑 Löschen</button>
                </form>
              </div>
            </div>
          </div>
          <?php $cnt = $pieceCounts[(int)$c['id']] ?? 0; ?>
          <?php if ($cnt): ?><div class="small" style="color:var(--green);margin-top:4px">🎵 <?=$cnt?> Stück<?=$cnt !== 1 ? 'e' : ''?></div><?php endif; ?>
        </div>

        <dialog id="dialog-edit-<?=h($c['id'])?>" class="sv-dialog">
          <div class="sv-dialog__panel" tabindex="-1">
            <div class="sv-dialog__head">
              <div class="sv-dialog__title">Auftritt bearbeiten</div>
              <button class="sv-dialog__close" type="button" data-close-dialog>✕</button>
            </div>
            <div class="sv-dialog__section"><?= concertFormHtml($c, 'update') ?></div>
          </div>
        </dialog>
      <?php endforeach; ?>
    </div>
  </div>

  <div>
    <?php if ($selected): ?>
      <div class="card" style="margin-bottom:12px">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
          <div>
            <h3 style="margin-bottom:4px"><?=h($selected['name'])?></h3>
            <div class="small" style="color:var(--muted)">
              <?php if ($selected['date']): ?><?=date('d.m.Y', strtotime($selected['date']))?><?php endif; ?>
              <?php if ($selected['location']): ?> · <?=h($selected['location'])?><?php endif; ?>
            </div>
            <?php if ($selected['notes']): ?><div class="small" style="margin-top:6px"><?=nl2br(h($selected['notes']))?></div><?php endif; ?>
          </div>
          <button class="btn" type="button" data-open-dialog="dialog-edit-<?=$selectedId?>">✏️ Bearbeiten</button>
        </div>
      </div>

      <div class="card" style="margin-bottom:12px">
        <h3 style="margin-bottom:12px">🎵 Programm (<?=count($selPieces)?> Stücke)</h3>
        <?php if ($selPieces): ?>
          <?php
            $totalSec = 0;
            foreach ($selPieces as $p) {
              $d = $p['duration'] ?? '';
              if (preg_match('/^(\d+):(\d{2})$/', $d, $m)) $totalSec += (int)$m[1]*60+(int)$m[2];
              elseif (preg_match("/^(\d+)'(\d{2})$/", $d, $m)) $totalSec += (int)$m[1]*60+(int)$m[2];
            }
          ?>
          <table>
            <thead><tr>
              <th style="width:30px">#</th>
              <th>Titel</th>
              <th>Komponist / Arrangeur</th>
              <th style="width:60px">Länge</th>
              <th style="width:40px"></th>
            </tr></thead>
            <tbody>
            <?php foreach ($selPieces as $i => $p): ?>
              <tr class="prog-row" data-pid="<?=h($p['id'])?>">
                <td class="small" style="color:var(--muted);text-align:center;cursor:grab" title="Ziehen zum Umsortieren">⠿</td>
                <td>
                  <button type="button" onclick="openPieceDetail(this)"
                    style="background:none;border:none;padding:0;cursor:pointer;text-align:left;font-family:inherit;font-size:inherit"
                    data-title="<?=h($p['title'])?>"
                    data-composer="<?=h($p['composer']??'')?>"
                    data-arranger="<?=h($p['arranger']??'')?>"
                    data-genre="<?=h($p['genre']??'')?>"
                    data-duration="<?=h($p['duration']??'')?>"
                    data-difficulty="<?=h($p['difficulty']??'')?>"
                    data-youtube="<?=h($p['youtube_url']??'')?>"
                    data-info="<?=h($p['info']??'')?>"
                    ><strong><?=h($p['title'])?></strong><?php if (!empty($p['querverweis'])): ?><span class="small" style="color:var(--muted)"> / <?=h($p['querverweis'])?></span><?php endif; ?></button>
                </td>
                <td class="small" style="color:var(--muted)">
                  <?=h($p['composer'] ?? '')?>
                  <?php if (!empty($p['arranger'])): ?><div style="font-size:11px">Arr. <?=h($p['arranger'])?></div><?php endif; ?>
                </td>
                <td class="small" style="white-space:nowrap"><?=h($p['duration'] ?? '–')?></td>
                <td>
                  <form method="post">
                    <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
                    <input type="hidden" name="action" value="remove_piece">
                    <input type="hidden" name="cid" value="<?=$selectedId?>">
                    <input type="hidden" name="pid" value="<?=h($p['id'])?>">
                    <button class="btn danger" type="submit" style="padding:2px 7px;font-size:12px">✕</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if ($totalSec > 0): ?>
              <tr style="border-top:2px solid var(--border)">
                <td colspan="3" style="font-weight:700;text-align:right;padding-right:12px">Gesamtdauer:</td>
                <td class="small" style="font-weight:700;white-space:nowrap"><?=floor($totalSec/60)?>:<?=str_pad($totalSec%60,2,'0',STR_PAD_LEFT)?></td>
                <td></td>
              </tr>
            <?php endif; ?>
            </tbody>
          </table>
        <?php else: ?>
          <div class="small" style="color:var(--muted)">Noch keine Stücke hinzugefügt.</div>
        <?php endif; ?>
      </div>

      <div class="card">
        <h3 style="margin-bottom:12px">Stück hinzufügen</h3>
        <form method="post" style="display:flex;gap:8px;align-items:flex-end">
          <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
          <input type="hidden" name="action" value="add_piece">
          <input type="hidden" name="cid" value="<?=$selectedId?>">
          <input type="hidden" name="pid" id="add-pid" value="">
          <label style="flex:1;position:relative">
            <input type="text" id="add-search" autocomplete="off" placeholder="Stück suchen…" style="width:100%" required>
            <div id="add-results" style="display:none;position:absolute;top:100%;left:0;right:0;background:#fff;border:1.5px solid var(--border);border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,.1);z-index:999;max-height:260px;overflow-y:auto;margin-top:3px"></div>
          </label>
          <button class="btn primary" type="submit" id="add-btn" disabled>+ Hinzufügen</button>
        </form>
      </div>

    <?php else: ?>
      <div class="card" style="display:flex;align-items:center;justify-content:center;min-height:200px;color:var(--muted)">
        ← Auftritt aus der Liste auswählen
      </div>
    <?php endif; ?>
  </div>

</div>

<dialog id="dialog-new-concert" class="sv-dialog">
  <div class="sv-dialog__panel" tabindex="-1">
    <div class="sv-dialog__head">
      <div class="sv-dialog__title">Neuer Auftritt</div>
      <button class="sv-dialog__close" type="button" data-close-dialog>✕</button>
    </div>
    <div class="sv-dialog__section"><?= concertFormHtml(null, 'create') ?></div>
  </div>
</dialog>

<dialog id="piece-detail-dlg" class="sv-dialog" style="width:min(520px,calc(100vw - 24px))">
  <div class="sv-dialog__panel" tabindex="-1">
    <div class="sv-dialog__head">
      <div>
        <div class="sv-dialog__title" id="pd-title"></div>
        <div class="sv-dialog__sub" id="pd-sub"></div>
      </div>
      <button class="sv-dialog__close" type="button" data-close-dialog>✕</button>
    </div>
    <div class="sv-dialog__section">
      <div id="pd-info" style="display:grid;grid-template-columns:1fr 1fr;gap:6px 16px;font-size:13px;margin-bottom:10px"></div>
      <div id="pd-yt"></div>
      <div id="pd-note" style="margin-top:10px;font-size:13px;color:var(--muted)"></div>
    </div>
  </div>
</dialog>

<style>
.piece-menu-item{display:block;width:100%;text-align:left;padding:9px 14px;font-size:13px;font-weight:600;background:none;border:none;cursor:pointer;color:var(--text);border-bottom:1px solid var(--border)}
.piece-menu-item:last-child{border-bottom:none}
.piece-menu-item:hover{background:#faf8f5}
.piece-menu form{margin:0}
.prog-row.drag-over{background:var(--green-light)!important}
.prog-row.dragging{opacity:.4}
#add-results .res-item{padding:9px 12px;cursor:pointer;font-size:13px;border-bottom:1px solid var(--border)}
#add-results .res-item:last-child{border-bottom:none}
#add-results .res-item:hover{background:#faf8f5}
#add-results .res-item.disabled{color:#bbb;cursor:default}
</style>

<script>
document.addEventListener('click', function(e) {
  var o = e.target.closest('[data-open-dialog]');
  if (o) { var d = document.getElementById(o.getAttribute('data-open-dialog')); if (d) d.showModal(); return; }
  var cl = e.target.closest('[data-close-dialog]');
  if (cl) { var d = cl.closest('dialog'); if (d) d.close(); }
});

function toggleMenu(btn) {
  var menu = btn.nextElementSibling;
  var open = menu.style.display !== 'none';
  closeMenus();
  if (!open) {
    menu.style.display = 'block';
    var r = btn.getBoundingClientRect();
    var mh = menu.offsetHeight || 100;
    menu.style.top   = (window.innerHeight - r.bottom < mh+8) ? (r.top-mh-4)+'px' : (r.bottom+4)+'px';
    menu.style.right = (window.innerWidth - r.right)+'px';
    setTimeout(function(){ document.addEventListener('click', closeOnOutside); }, 0);
  }
}
function closeMenus() {
  document.querySelectorAll('.piece-menu').forEach(function(m){ m.style.display='none'; });
  document.removeEventListener('click', closeOnOutside);
}
function closeOnOutside(e) {
  if (!e.target.closest('.piece-menu') && !e.target.closest('[onclick*="toggleMenu"]')) closeMenus();
}

var dragRow = null;
document.querySelectorAll('.prog-row').forEach(function(row) {
  row.setAttribute('draggable', 'true');
  row.addEventListener('dragstart', function(e) { dragRow = row; row.classList.add('dragging'); e.dataTransfer.effectAllowed='move'; });
  row.addEventListener('dragend', function() { row.classList.remove('dragging'); document.querySelectorAll('.prog-row').forEach(function(r){ r.classList.remove('drag-over'); }); saveOrder(); });
  row.addEventListener('dragover', function(e) { e.preventDefault(); e.dataTransfer.dropEffect='move'; document.querySelectorAll('.prog-row').forEach(function(r){ r.classList.remove('drag-over'); }); row.classList.add('drag-over'); });
  row.addEventListener('drop', function(e) {
    e.preventDefault();
    if (dragRow && dragRow !== row) {
      var tbody = row.closest('tbody');
      var rows  = Array.from(tbody.querySelectorAll('.prog-row'));
      var fromIdx = rows.indexOf(dragRow);
      var toIdx   = rows.indexOf(row);
      if (fromIdx < toIdx) row.after(dragRow); else row.before(dragRow);
      tbody.querySelectorAll('.prog-row').forEach(function(r, i){
        r.querySelector('td:first-child').textContent = (i+1) + '.';
      });
    }
  });
});

function saveOrder() {
  var rows = document.querySelectorAll('.prog-row');
  if (!rows.length) return;
  var pids = Array.from(rows).map(function(r){ return r.dataset.pid; });
  var cid  = <?= $selectedId ?: 0 ?>;
  var csrf = '<?= addslashes(sv_csrf_token()) ?>';
  var body = 'action=reorder&csrf='+encodeURIComponent(csrf)+'&cid='+cid;
  pids.forEach(function(pid){ body += '&pids[]='+pid; });
  fetch('concerts.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:body });
}

var allPieces = <?= $allPiecesJson ?: '[]' ?>;
var usedIds   = [<?= implode(',', array_map('intval', array_column($selPieces, 'id'))) ?>];
var addSearch = document.getElementById('add-search');
var addResults= document.getElementById('add-results');
var addPid    = document.getElementById('add-pid');
var addBtn    = document.getElementById('add-btn');

if (addSearch) {
  addSearch.addEventListener('input', function() {
    var q = this.value.trim().toLowerCase();
    addResults.innerHTML = '';
    addPid.value = '';
    addBtn.disabled = true;
    if (!q) { addResults.style.display='none'; return; }
    var matches = allPieces.filter(function(p){ return p.title.toLowerCase().includes(q) || (p.composer || '').toLowerCase().includes(q); }).slice(0,12);
    if (!matches.length) { addResults.style.display='none'; return; }
    matches.forEach(function(p) {
      var div = document.createElement('div');
      var used = usedIds.includes(p.id);
      div.className = 'res-item' + (used ? ' disabled' : '');
      div.textContent = p.title + (p.composer ? ' (' + p.composer + ')' : '') + (used ? ' ✓' : '');
      if (!used) div.addEventListener('click', function(){
        addPid.value = p.id;
        addSearch.value = p.title;
        addResults.style.display = 'none';
        addBtn.disabled = false;
      });
      addResults.appendChild(div);
    });
    addResults.style.display = 'block';
  });
  document.addEventListener('click', function(e){ if (!addSearch.contains(e.target) && !addResults.contains(e.target)) addResults.style.display='none'; });
}

function openPieceDetail(btn) {
  var dlg = document.getElementById('piece-detail-dlg');
  document.getElementById('pd-title').textContent = btn.dataset.title || '';
  var sub = [];
  if (btn.dataset.composer) sub.push(btn.dataset.composer);
  if (btn.dataset.arranger) sub.push('Arr. ' + btn.dataset.arranger);
  document.getElementById('pd-sub').textContent = sub.join(' · ');
  var info = document.getElementById('pd-info');
  info.innerHTML = '';
  [['Genre', btn.dataset.genre],['Länge', btn.dataset.duration],['Grad', btn.dataset.difficulty ? parseFloat(btn.dataset.difficulty).toFixed(1) : '']].forEach(function(f){
    if (!f[1]) return;
    info.innerHTML += '<div><span style="color:var(--muted)">' + f[0] + ':</span> <strong>' + escH(f[1]) + '</strong></div>';
  });
  document.getElementById('pd-yt').innerHTML = btn.dataset.youtube
    ? '<a class="song-link" href="' + escH(btn.dataset.youtube) + '" target="_blank" rel="noopener">▶ YouTube öffnen</a>' : '';
  document.getElementById('pd-note').textContent = btn.dataset.info || '';
  dlg.showModal();
}
function escH(s){ var d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }
</script>
<?php sv_footer(); ?>
