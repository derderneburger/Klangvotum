<?php
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/layout.php';

$admin = sv_require_admin();
$pdo   = sv_pdo();
$base  = sv_base_url();

$rows = $pdo->query("
  SELECT s.id, s.title, s.youtube_url,
         SUM(v.vote='ja') AS ja, SUM(v.vote='nein') AS nein, SUM(v.vote='neutral') AS neutral,
         COUNT(v.vote) AS votes_total,
         (SUM(v.vote='ja') - SUM(v.vote='nein')) AS score
  FROM songs s
  LEFT JOIN votes v ON v.song_id=s.id
  WHERE s.is_active=1
  GROUP BY s.id
  ORDER BY score DESC, ja DESC, s.id ASC
")->fetchAll();

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename="klangvotum_topliste_' . date('Y-m-d_H-i') . '.csv"');
  $out = fopen('php://output', 'w');
  fputcsv($out, ['song_id','title','youtube_url','ja','nein','neutral','votes_total','score'], ';');
  foreach ($rows as $r) {
    fputcsv($out, [$r['id'],$r['title'],$r['youtube_url'],$r['ja'],$r['nein'],$r['neutral'],$r['votes_total'],$r['score']], ';');
  }
  fclose($out); exit;
}

$top5  = array_slice($rows, 0, 5);
$maxAbs = 1;
foreach ($top5 as $r) $maxAbs = max($maxAbs, abs((int)$r['score']));

sv_header('Admin – Top 5', $admin);
?>

<div class="page-header">
  <div>
    <h2>Top 5</h2>
    <div class="small">Live-Ranking der beliebtesten Stücke (Score = Ja − Nein).</div>
  </div>
  <div class="row">
    <a class="btn" href="<?=h($base)?>/admin/heatmap.php?export=csv">CSV Export</a>
    <a class="btn" href="<?=h($base)?>/admin/">← Admin</a>
  </div>
</div>

<div class="card" style="margin-bottom:12px">
  <table>
    <thead>
      <tr><th>#</th><th>Titel</th><th>Ja</th><th>Neutral</th><th>Nein</th><th>Score</th><th style="min-width:120px">Visualisierung</th></tr>
    </thead>
    <tbody>
      <?php $i=1; foreach ($top5 as $r):
        $score    = (int)$r['score'];
        $w        = $maxAbs ? (int)round((abs($score)/$maxAbs)*100) : 0;
        $barClass = $score >= 0 ? 'heat-pos' : 'heat-neg';
      ?>
      <tr>
        <td><strong><?=h($i++)?></strong></td>
        <td>
          <div class="song-title"><?=h($r['title'])?></div>
          <?php if (!empty($r['youtube_url'])): ?>
            <a class="small" href="<?=h($r['youtube_url'])?>" target="_blank" rel="noopener">YouTube öffnen</a>
          <?php endif; ?>
        </td>
        <td><?=h($r['ja'])?></td>
        <td><?=h($r['neutral'])?></td>
        <td><?=h($r['nein'])?></td>
        <td><span class="badge"><?=h($score)?></span></td>
        <td><div class="heatbar"><div class="<?=h($barClass)?>" style="width:<?=$w?>%"></div></div></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$top5): ?><tr><td colspan="7" class="small">Noch keine Titel oder Stimmen.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<div class="card">
  <h3>Hinweis</h3>
  <div class="small">
    Um Stücke zu archivieren ohne Daten zu verlieren: Setze sie auf <strong>inaktiv</strong> (is_active=0) — 
    alte Stimmen bleiben erhalten und du kannst für die neue Runde neue Titel hinzufügen.
  </div>
</div>

<?php sv_footer(); ?>
