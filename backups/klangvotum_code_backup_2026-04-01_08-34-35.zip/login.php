<?php
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/layout.php';

sv_start_session();
$user = sv_current_user();
if ($user) { header('Location: index.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  sv_csrf_check();
  $username = trim($_POST['username'] ?? '');
  $password = (string)($_POST['password'] ?? '');
  if (sv_login($username, $password)) { header('Location: index.php'); exit; }
  $error = 'Login fehlgeschlagen – Benutzername oder Passwort falsch.';
}

sv_header('Login');

$cfg = sv_config();
$brand = $cfg['branding'] ?? [];
$logoPath = $brand['logo_path'] ?? 'assets/logo.svg';
$base = sv_base_url();
$logoFs = __DIR__ . '/' . ltrim($logoPath, '/');
$logoUrl = is_file($logoFs) ? ($base . '/' . ltrim($logoPath, '/')) : null;
?>

<div class="auth-page">
  <div class="auth-card card grid">
    <?php if ($logoUrl): ?>
      <div class="auth-logo-wrap">
        <img class="auth-logo" src="<?=h($logoUrl)?>" alt="Logo">
      </div>
    <?php else: ?>
      <div class="auth-logo-wrap" style="font-size:48px">🎵</div>
    <?php endif; ?>

    <h2 class="auth-title">Willkommen</h2>
    <p class="small" style="text-align:center;margin-top:-6px">Melde dich an, um abzustimmen</p>

    <?php if ($error): ?>
      <div class="notice error"><?=h($error)?></div>
    <?php endif; ?>

    <form method="post" class="grid" autocomplete="on" style="margin-top:4px">
      <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
      <label style="display:block">
        Benutzername
        <input name="username" required style="width:100%;margin-top:5px" autocomplete="username">
      </label>
      <label style="display:block">
        Passwort
        <input name="password" type="password" required style="width:100%;margin-top:5px" autocomplete="current-password">
      </label>
      <button class="btn primary" type="submit" style="width:100%;justify-content:center;padding:11px">Einloggen</button>
    </form>
  </div>
</div>

<?php sv_footer(); ?>
