<?php
function sv_config(): array {
  static $cfg = null;
  if ($cfg === null) $cfg = require __DIR__ . '/../configv2.php';
  return $cfg;
}

function sv_pdo(): PDO {
  static $pdo = null;
  if ($pdo) return $pdo;
  $c = sv_config()['db'];
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', $c['host'], $c['name'], $c['charset']);
  $pdo = new PDO($dsn, $c['user'], $c['pass'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
  ]);
  sv_ensure_schema($pdo);
  return $pdo;
}


function sv_ensure_schema(PDO $pdo): void {

  // ── Bestehende Hilfstabellen ──────────────────────────────────────────────
  $pdo->exec("CREATE TABLE IF NOT EXISTS user_activity (
      user_id INT NOT NULL,
      last_activity DATETIME NOT NULL,
      last_ip VARCHAR(45) NULL,
      last_user_agent VARCHAR(255) NULL,
      PRIMARY KEY (user_id),
      KEY idx_last_activity (last_activity)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
      username VARCHAR(190) NOT NULL,
      ip VARCHAR(45) NOT NULL,
      attempts INT NOT NULL DEFAULT 0,
      first_attempt DATETIME NOT NULL,
      locked_until DATETIME NULL,
      PRIMARY KEY (username, ip),
      KEY idx_locked_until (locked_until)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  // ── v2: users.role ────────────────────────────────────────────────────────
  // Spalte role hinzufügen falls noch nicht vorhanden
  $cols = $pdo->query("SHOW COLUMNS FROM users LIKE 'role'")->fetchAll();
  if (empty($cols)) {
    $pdo->exec("ALTER TABLE users ADD COLUMN role ENUM('user','leitung','admin') NOT NULL DEFAULT 'user' AFTER is_admin");
    // Migration: is_admin=1 → role=admin, sonst role=user
    $pdo->exec("UPDATE users SET role = CASE WHEN is_admin = 1 THEN 'admin' ELSE 'user' END");
  }

  // ── v2: songs — neue Felder ───────────────────────────────────────────────
  $songCols = array_column($pdo->query("SHOW COLUMNS FROM songs")->fetchAll(), 'Field');
  if (!in_array('piece_id', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN piece_id INT NULL AFTER is_active");
  }
  if (!in_array('composer', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN composer VARCHAR(255) NULL AFTER piece_id");
  }
  if (!in_array('arranger', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN arranger VARCHAR(255) NULL AFTER composer");
  }
  if (!in_array('publisher', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN publisher VARCHAR(255) NULL AFTER arranger");
  }
  if (!in_array('duration', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN duration VARCHAR(20) NULL AFTER publisher");
  }
  if (!in_array('genre', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN genre VARCHAR(100) NULL AFTER duration");
  }
  if (!in_array('difficulty', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN difficulty DECIMAL(3,1) NULL AFTER publisher");
  }
  if (!in_array('shop_url', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN shop_url VARCHAR(512) NULL AFTER difficulty");
  }
  if (!in_array('shop_price', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN shop_price DECIMAL(8,2) NULL AFTER shop_url");
  }
  if (!in_array('info', $songCols)) {
    $pdo->exec("ALTER TABLE songs ADD COLUMN info TEXT NULL AFTER shop_price");
  }

  // ── v2: pieces — Notenbibliothek ──────────────────────────────────────────
  $pdo->exec("CREATE TABLE IF NOT EXISTS pieces (
      id               INT NOT NULL AUTO_INCREMENT,
      title            VARCHAR(255) NOT NULL,
      youtube_url      VARCHAR(512) NULL,
      composer         VARCHAR(255) NULL,
      arranger         VARCHAR(255) NULL,
      publisher        VARCHAR(255) NULL,
      duration         VARCHAR(20)  NULL,
      difficulty       DECIMAL(3,1) NULL,
      genre            VARCHAR(100) NULL,
      owner            VARCHAR(100) NULL,
      has_scan         TINYINT(1)   NOT NULL DEFAULT 0,
      has_score_scan   TINYINT(1)   NOT NULL DEFAULT 0,
      has_original_score TINYINT(1) NOT NULL DEFAULT 0,
      folder_number    INT          NULL,
      binder           VARCHAR(10)  NULL,
      shop_url         VARCHAR(512) NULL,
      shop_price       DECIMAL(8,2) NULL,
      info             TEXT         NULL,
      notes            TEXT         NULL,
      created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_pieces_title_arr (title, arranger(100)),
      KEY idx_pieces_composer (composer(50))
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  // ── v2: concerts — Auftrittskronik ────────────────────────────────────────
  $pdo->exec("CREATE TABLE IF NOT EXISTS concerts (
      id         INT NOT NULL AUTO_INCREMENT,
      name       VARCHAR(255) NOT NULL,
      date       DATE         NULL,
      location   VARCHAR(255) NULL,
      notes      TEXT         NULL,
      created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_concerts_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  // ── v2: pieces — UNIQUE KEY auf title+arranger ändern ──────────────────────
  try {
    // Alten title-only unique key entfernen falls vorhanden
    $idxList = $pdo->query("SHOW INDEX FROM pieces WHERE Key_name = 'uq_pieces_title'")->fetchAll();
    if ($idxList) $pdo->exec("ALTER TABLE pieces DROP INDEX uq_pieces_title");
    // Neuen title+arranger unique key hinzufügen falls nicht vorhanden
    $newIdx = $pdo->query("SHOW INDEX FROM pieces WHERE Key_name = 'uq_pieces_title_arr'")->fetchAll();
    if (!$newIdx) $pdo->exec("ALTER TABLE pieces ADD UNIQUE KEY uq_pieces_title_arr (title, arranger(100))");
  } catch (Throwable $e) {}

  // ── v2: pieces — neue Felder für bestehende Installationen ──────────────────
  $pieceCols = array_column($pdo->query("SHOW COLUMNS FROM pieces")->fetchAll(), 'Field');
  if (!in_array('youtube_url',$pieceCols)) $pdo->exec("ALTER TABLE pieces ADD COLUMN youtube_url VARCHAR(512) NULL AFTER title");
  if (!in_array('duration',   $pieceCols)) $pdo->exec("ALTER TABLE pieces ADD COLUMN duration   VARCHAR(20)  NULL AFTER publisher");
  if (!in_array('genre',      $pieceCols)) $pdo->exec("ALTER TABLE pieces ADD COLUMN genre      VARCHAR(100) NULL AFTER duration");
  if (!in_array('shop_url',   $pieceCols)) $pdo->exec("ALTER TABLE pieces ADD COLUMN shop_url   VARCHAR(512) NULL AFTER binder");
  if (!in_array('shop_price', $pieceCols)) $pdo->exec("ALTER TABLE pieces ADD COLUMN shop_price DECIMAL(8,2) NULL AFTER shop_url");
  if (!in_array('info',        $pieceCols)) $pdo->exec("ALTER TABLE pieces ADD COLUMN info        TEXT         NULL AFTER shop_price");
  if (!in_array('querverweis', $pieceCols)) $pdo->exec("ALTER TABLE pieces ADD COLUMN querverweis VARCHAR(255) NULL AFTER info");


  // ── v2: vote_history — historische Stimmen nach Archivierung ────────────────
  $pdo->exec("CREATE TABLE IF NOT EXISTS vote_history (
      id          INT NOT NULL AUTO_INCREMENT,
      user_id     INT NOT NULL,
      piece_id    INT NOT NULL,
      vote        ENUM('ja','nein','neutral') NOT NULL,
      note        TEXT NULL,
      archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_vh_user_piece (user_id, piece_id),
      KEY idx_vh_piece (piece_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  // ── v2: concert_pieces — Verknüpfung Auftritt ↔ Stück ────────────────────
  $pdo->exec("CREATE TABLE IF NOT EXISTS concert_pieces (
      id         INT NOT NULL AUTO_INCREMENT,
      concert_id INT NOT NULL,
      piece_id   INT NOT NULL,
      position   INT NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uq_concert_piece (concert_id, piece_id),
      KEY idx_cp_concert (concert_id),
      KEY idx_cp_piece   (piece_id),
      CONSTRAINT fk_cp_concert FOREIGN KEY (concert_id) REFERENCES concerts (id) ON DELETE CASCADE,
      CONSTRAINT fk_cp_piece   FOREIGN KEY (piece_id)   REFERENCES pieces   (id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function sv_base_url(): string {
  $cfg = sv_config();
  if (!empty($cfg['base_url'])) return rtrim($cfg['base_url'], '/');
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') == '443');
  $scheme = $https ? 'https' : 'http';
  $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
  $script = $_SERVER['SCRIPT_NAME'] ?? '';
  $path = rtrim(str_replace(basename($script), '', $script), '/');
  return $scheme . '://' . $host . $path;
}

function sv_log(?int $user_id, string $action, ?string $details = null): void {
  try {
    $pdo = sv_pdo();
    $stmt = $pdo->prepare("INSERT INTO audit_log (user_id, action, details) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $action, $details]);
  } catch (Throwable $e) {}
}

function sv_is_frozen(): bool {
  try {
    $pdo = sv_pdo();
    $stmt = $pdo->query("SELECT action FROM audit_log WHERE action IN ('freeze_on','freeze_off') ORDER BY id DESC LIMIT 1");
    $row = $stmt->fetch();
    if (!$row) return false;
    return $row['action'] === 'freeze_on';
  } catch (Throwable $e) {
    return false;
  }
}

function sv_set_frozen(int $admin_user_id, bool $on): void {
  sv_log($admin_user_id, $on ? 'freeze_on' : 'freeze_off', null);
}
