<?php
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/layout.php';

$admin = sv_require_admin();
$pdo   = sv_pdo();
$base  = sv_base_url();

function songFields(): array {
  return [
    'title'      => trim($_POST['title']      ?? ''),
    'youtube_url'=> trim($_POST['youtube_url']?? ''),
    'composer'   => trim($_POST['composer']   ?? ''),
    'arranger'   => trim($_POST['arranger']   ?? ''),
    'publisher'  => trim($_POST['publisher']  ?? ''),
    'duration'   => sv_normalize_duration(trim($_POST['duration'] ?? '')),
    'genre'      => trim($_POST['genre']      ?? ''),
    'difficulty' => (isset($_POST['difficulty']) && $_POST['difficulty'] !== '') ? (float)str_replace(',','.',$_POST['difficulty']) : null,
    'shop_url'   => trim($_POST['shop_url']   ?? ''),
    'shop_price' => (isset($_POST['shop_price']) && $_POST['shop_price'] !== '') ? (float)str_replace(',','.',$_POST['shop_price']) : null,
    'info'       => trim($_POST['info']       ?? ''),
  ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  sv_csrf_check();
  $action = $_POST['action'] ?? '';

  if ($action === 'create') {
    $f = songFields();
    if ($f['title'] === '') { sv_flash_set('error', 'Titel ist Pflichtfeld.'); }
    elseif ($f['youtube_url'] === '') { sv_flash_set('error', 'YouTube URL ist Pflichtfeld.'); }
    else {
      $stmt = $pdo->prepare("INSERT INTO songs (title,youtube_url,composer,arranger,publisher,duration,genre,difficulty,shop_url,shop_price,info) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
      $stmt->execute([$f['title'],$f['youtube_url'],$f['composer'],$f['arranger'],$f['publisher'],$f['duration'],$f['genre'],$f['difficulty'],$f['shop_url'],$f['shop_price'],$f['info']]);
      sv_log($admin['id'], 'song_create', $f['title']);
      sv_flash_set('success', 'Titel angelegt.');
    }

  } elseif ($action === 'update') {
    $sid = (int)($_POST['sid'] ?? 0);
    $f   = songFields();
    if ($sid <= 0 || $f['title'] === '') { sv_flash_set('error', 'Titel ist Pflichtfeld.'); }
    elseif ($f['youtube_url'] === '') { sv_flash_set('error', 'YouTube URL ist Pflichtfeld.'); }
    else {
      $stmt = $pdo->prepare("UPDATE songs SET title=?,youtube_url=?,composer=?,arranger=?,publisher=?,duration=?,genre=?,difficulty=?,shop_url=?,shop_price=?,info=? WHERE id=?");
      $stmt->execute([$f['title'],$f['youtube_url'],$f['composer'],$f['arranger'],$f['publisher'],$f['duration'],$f['genre'],$f['difficulty'],$f['shop_url'],$f['shop_price'],$f['info'],$sid]);
      // Sync zu verknuepftem Archiveintrag
      $linkedP = $pdo->prepare("SELECT piece_id FROM songs WHERE id=?"); $linkedP->execute([$sid]);
      $linkedPid = (int)($linkedP->fetchColumn() ?: 0);
      if ($linkedPid) {
        $pdo->prepare("UPDATE pieces SET title=?,youtube_url=?,composer=?,arranger=?,publisher=?,duration=?,genre=?,difficulty=?,shop_url=?,shop_price=?,info=? WHERE id=?")
          ->execute([$f['title'],$f['youtube_url'],$f['composer'],$f['arranger'],$f['publisher'],$f['duration'],$f['genre'],$f['difficulty'],$f['shop_url'],$f['shop_price'],$f['info'],$linkedPid]);
      }
      sv_log($admin['id'], 'song_update', "song_id=$sid".($linkedPid?" sync_piece=$linkedPid":''));
      sv_flash_set('success', 'Titel aktualisiert.'.($linkedPid?' (Archiv synchronisiert)':''));
    }

  } elseif ($action === 'toggle_active') {
    $sid = (int)($_POST['sid'] ?? 0);
    $pdo->prepare("UPDATE songs SET is_active = 1 - is_active WHERE id=?")->execute([$sid]);
    sv_log($admin['id'], 'song_toggle', "song_id=$sid");
    sv_flash_set('success', 'Status geändert.');

  } elseif ($action === 'to_archive') {
    $sid       = (int)($_POST['sid'] ?? 0);
    $forceLink = !empty($_POST['force_link']);
    $linkPid   = (int)($_POST['link_piece_id'] ?? 0); // Variante C: User wählt konkreten Archiveintrag
    $mergeFields = !empty($_POST['merge_fields']); // Felder aus Song übernehmen?
    if ($sid > 0) {
      $s = $pdo->prepare("SELECT * FROM songs WHERE id=?");
      $s->execute([$sid]);
      $s = $s->fetch();
      if ($s && $s['piece_id']) {
        sv_flash_set('error', '„'.$s['title'].'" ist bereits mit einem Archiveintrag verknüpft.');
      } elseif ($s) {
        // Alle Archiveinträge mit gleichem Titel suchen (für Typo-Erkennung)
        $allSameTitleStmt = $pdo->prepare("SELECT id, composer, arranger, duration, publisher FROM pieces WHERE title=?");
        $allSameTitleStmt->execute([$s['title']]);
        $allSameTitle = $allSameTitleStmt->fetchAll();

        // Exakter Match: Titel + Arrangeur
        $existingPiece = null;
        foreach ($allSameTitle as $p) {
          if (($p['arranger'] ?? '') === ($s['arranger'] ?? '')) {
            $existingPiece = $p;
            break;
          }
        }

        if (($existingPiece || count($allSameTitle) > 0) && !$forceLink && !$linkPid) {
          // Session: Song-Daten für den Vergleichs-Dialog speichern
          $_SESSION['archive_conflict'] = [
            'sid'         => $sid,
            'song'        => $s,
            'matches'     => $allSameTitle,
            'exact_match' => $existingPiece,
          ];
          sv_flash_set('error', '__archive_conflict__');
        } elseif ($linkPid) {
          // User hat explizit einen Archiveintrag gewählt
          $existingPiece = $pdo->prepare("SELECT * FROM pieces WHERE id=?")->execute([$linkPid]) ? null : null;
          $pStmt = $pdo->prepare("SELECT * FROM pieces WHERE id=?");
          $pStmt->execute([$linkPid]);
          $existingPiece = $pStmt->fetch();
          if ($existingPiece) {
            $pieceId = $linkPid;
            // Felder aus Song übernehmen wenn gewünscht
            if ($mergeFields) {
              $pdo->prepare("UPDATE pieces SET
                youtube_url=COALESCE(NULLIF(?,  ''), youtube_url),
                composer   =COALESCE(NULLIF(?,  ''), composer),
                arranger   =COALESCE(NULLIF(?,  ''), arranger),
                publisher  =COALESCE(NULLIF(?,  ''), publisher),
                duration   =COALESCE(NULLIF(?,  ''), duration),
                genre      =COALESCE(NULLIF(?,  ''), genre),
                difficulty =COALESCE(?,              difficulty),
                shop_url   =COALESCE(NULLIF(?,  ''), shop_url),
                shop_price =COALESCE(?,              shop_price),
                info       =COALESCE(NULLIF(?,  ''), info)
                WHERE id=?")->execute([
                  $s['youtube_url'],$s['composer'],$s['arranger'],
                  $s['publisher'],$s['duration'],$s['genre'],
                  $s['difficulty'],$s['shop_url'],$s['shop_price'],$s['info'],
                  $pieceId
              ]);
            }
            try {
              $pdo->prepare("INSERT INTO vote_history (user_id, piece_id, vote, note, archived_at)
                SELECT v.user_id, ?, v.vote, vn.note, NOW()
                FROM votes v
                LEFT JOIN vote_notes vn ON vn.song_id = v.song_id AND vn.user_id = v.user_id
                WHERE v.song_id = ?
                ON DUPLICATE KEY UPDATE vote=VALUES(vote), note=VALUES(note), archived_at=NOW()
              ")->execute([$pieceId, $sid]);
              $pdo->prepare("DELETE FROM songs WHERE id=?")->execute([$sid]);
              sv_log($admin['id'], 'song_to_archive', "song_id=$sid piece_id=$pieceId linked");
              sv_flash_set('success', '„'.$s['title'].'" mit Archiv verknüpft und aus Abstimmung entfernt.');
            } catch (Throwable $e) {
              sv_flash_set('error', 'Fehler: '.$e->getMessage());
            }
          }
        } else {
          try {
            if ($existingPiece) {
              $pieceId = (int)$existingPiece['id'];
            } else {
              $stmt = $pdo->prepare("INSERT INTO pieces (title,youtube_url,composer,arranger,publisher,duration,genre,difficulty,shop_url,shop_price,info) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
              $stmt->execute([$s['title'],$s['youtube_url'],$s['composer'],$s['arranger'],$s['publisher'],$s['duration'],$s['genre'],$s['difficulty'],$s['shop_url'],$s['shop_price'],$s['info']]);
              $pieceId = (int)$pdo->lastInsertId();
            }
            if ($pieceId) {
              // Votes + Notizen in vote_history sichern (historischer Hinweis)
              $pdo->prepare("
                INSERT INTO vote_history (user_id, piece_id, vote, note, archived_at)
                SELECT v.user_id, ?, v.vote, vn.note, NOW()
                FROM votes v
                LEFT JOIN vote_notes vn ON vn.song_id = v.song_id AND vn.user_id = v.user_id
                WHERE v.song_id = ?
                ON DUPLICATE KEY UPDATE vote=VALUES(vote), note=VALUES(note), archived_at=NOW()
              ")->execute([$pieceId, $sid]);
              // Song löschen (votes/notes werden durch DB-Cascade oder einfach obsolet)
              $pdo->prepare("DELETE FROM songs WHERE id=?")->execute([$sid]);
              sv_log($admin['id'], 'song_to_archive', "song_id=$sid piece_id=$pieceId");
              $verb = $existingPiece ? 'mit Archiv verknüpft' : 'ins Archiv übertragen';
              sv_flash_set('success', '„'.$s['title'].'" '.$verb.' und aus Abstimmung entfernt.');
            }
          } catch (Throwable $e) {
            sv_flash_set('error', 'Fehler: '.$e->getMessage());
          }
        }
      }
    }

  } elseif ($action === 'delete') {
    $sid = (int)($_POST['sid'] ?? 0);
    // Votes/Notes piece_id setzen falls vorhanden, dann Song löschen
    $songCheck = $pdo->prepare("SELECT piece_id FROM songs WHERE id=?");
    $songCheck->execute([$sid]);
    $songRow = $songCheck->fetch();
    if ($songRow && $songRow['piece_id']) {
      $pdo->prepare("
        INSERT INTO vote_history (user_id, piece_id, vote, note, archived_at)
        SELECT v.user_id, ?, v.vote, vn.note, NOW()
        FROM votes v
        LEFT JOIN vote_notes vn ON vn.song_id = v.song_id AND vn.user_id = v.user_id
        WHERE v.song_id = ?
        ON DUPLICATE KEY UPDATE vote=VALUES(vote), note=VALUES(note), archived_at=NOW()
      ")->execute([$songRow['piece_id'], $sid]);
    }
    $pdo->prepare("DELETE FROM songs WHERE id=?")->execute([$sid]);
    sv_log($admin['id'], 'song_delete', "song_id=$sid");
    sv_flash_set('success', 'Titel gelöscht.');
  }

  $redirectParams = array_filter([
    'q'    => $_POST['_q']    ?? '',
    'sort' => $_POST['_sort'] ?? '',
    'dir'  => $_POST['_dir']  ?? '',
  ]);
  $redirectSuffix = $redirectParams ? '?' . http_build_query($redirectParams) : '';
  header('Location: '.$base.'/admin/abstimmungstitel.php'.$redirectSuffix);
  exit;
}

// ── Filter & Sortierung ───────────────────────────────────────────────────────
$search  = trim($_GET['q']      ?? '');
$fActive = $_GET['active']      ?? '';
$sortBy  = in_array($_GET['sort']??'', ['title','composer','arranger','genre','difficulty','duration','status']) ? ($_GET['sort']??'title') : 'title';
$sortDir = ($_GET['dir']  ?? '') === 'desc' ? 'DESC' : 'ASC';

$conds  = [];
$params = [];
if ($search !== '') {
  $conds[] = "(s.title LIKE ? OR s.composer LIKE ? OR s.arranger LIKE ? OR s.genre LIKE ?)";
  $params  = array_merge($params, ["%$search%","%$search%","%$search%","%$search%"]);
}
if ($fActive === '1') { $conds[] = "s.is_active = 1"; }
if ($fActive === '0') { $conds[] = "s.is_active = 0"; }

$where   = $conds ? "WHERE ".implode(" AND ", $conds) : "";
if ($sortBy==='difficulty') { $orderBy="s.difficulty IS NULL, s.difficulty $sortDir, s.title ASC"; }
elseif ($sortBy==='composer') { $orderBy="s.composer IS NULL OR s.composer='', s.composer $sortDir, s.title ASC"; }
elseif ($sortBy==='arranger') { $orderBy="s.arranger IS NULL OR s.arranger='', s.arranger $sortDir, s.title ASC"; }
elseif ($sortBy==='genre')    { $orderBy="s.genre IS NULL OR s.genre='', s.genre $sortDir, s.title ASC"; }
elseif ($sortBy==='duration') { $orderBy="(CASE WHEN s.duration IS NULL OR s.duration='' THEN 99999 WHEN s.duration REGEXP '^[0-9]+[:][0-9]+' THEN CAST(SUBSTRING_INDEX(s.duration,':',1) AS UNSIGNED)*60+CAST(SUBSTRING_INDEX(s.duration,':',-1) AS UNSIGNED) ELSE CAST(s.duration AS UNSIGNED)*60 END) $sortDir, s.title ASC"; }
elseif ($sortBy==='status')   { $orderBy="s.is_active $sortDir, s.title ASC"; }
else { $orderBy="s.title $sortDir"; }

$stmt = $pdo->prepare("SELECT s.*, p.title AS piece_title FROM songs s LEFT JOIN pieces p ON p.id=s.piece_id $where ORDER BY $orderBy");
$stmt->execute($params);
$songs = $stmt->fetchAll();

sv_header('Admin – Titel', $admin);

function diffPill(mixed $d): string {
  if ($d === null || $d === '') return '<span class="small" style="color:#bbb">–</span>';
  $d = (float)$d;
  if ($d <= 2)     $style = 'background:var(--green-light);color:var(--green);border-color:var(--green-mid)';
  elseif ($d <= 4) $style = 'background:#fff8e1;color:#b8860b;border-color:rgba(184,134,11,.3)';
  else             $style = 'background:var(--red-soft);color:var(--red);border-color:rgba(193,9,15,.3)';
  return '<span class="badge" style="'.$style.'">'.number_format($d,1).'</span>';
}

function songFormFields(array $s): string {
  $v = fn(string $k) => htmlspecialchars((string)($s[$k]??''), ENT_QUOTES, 'UTF-8');
  ob_start(); ?>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
    <label style="grid-column:1/-1">Titel *<br><input name="title" required value="<?=$v('title')?>" style="width:100%;margin-top:5px"></label>
    <div style="grid-column:1/-1;display:flex;gap:8px">
      <button type="button" class="btn" style="flex:1;justify-content:center" onclick="openSearchWindow(this, 'google')">🌐 Google-Suche</button>
      <button type="button" class="btn" style="flex:1;justify-content:center" onclick="openSearchWindow(this, 'youtube')">▶ YouTube-Suche</button>
    </div>
    <label style="grid-column:1/-1">
      <span style="display:flex;align-items:center;justify-content:space-between;margin-bottom:5px">
        <span class="yt-label">YouTube URL *</span>
        <button type="button" class="btn" style="font-size:11px;padding:2px 8px" onclick="toggleYtRequired(this)">Pflicht aufheben</button>
      </span>
      <input class="yt-input" name="youtube_url" required value="<?=$v('youtube_url')?>" placeholder="https://youtu.be/…" style="width:100%">
    </label>
    <label>Komponist<br><input name="composer" value="<?=$v('composer')?>" style="width:100%;margin-top:5px"></label>
    <label>Arrangeur<br><input name="arranger" value="<?=$v('arranger')?>" style="width:100%;margin-top:5px"></label>
    <label style="grid-column:1/-1">Verlag<br><input name="publisher" value="<?=$v('publisher')?>" style="width:100%;margin-top:5px"></label>
    <label>Länge<br><input name="duration" value="<?=$v('duration')?>" placeholder="z.B. 6'30" style="width:100%;margin-top:5px"></label>
    <label>Genre<br><input name="genre" value="<?=$v('genre')?>" placeholder="z.B. Konzertmarsch" style="width:100%;margin-top:5px"></label>
    <label>Grad (1.0–6.0)<br><input name="difficulty" type="number" step="0.1" min="1" max="6" value="<?=$v('difficulty')?>" style="width:100%;margin-top:5px"></label>
    <label>Preis (€)<br><input name="shop_price" type="number" step="0.01" min="0" value="<?=$v('shop_price')?>" style="width:100%;margin-top:5px"></label>
    <label style="grid-column:1/-1">Link zum Händler<br><input name="shop_url" value="<?=$v('shop_url')?>" placeholder="https://…" style="width:100%;margin-top:5px"></label>
    <label style="grid-column:1/-1">Info-Text<br><textarea name="info" rows="2" style="width:100%;margin-top:5px"><?=$v('info')?></textarea></label>
  </div>
  <?php return ob_get_clean();
}
?>

<div class="page-header">
  <div>
    <h2>Titel</h2>
    <div class="muted">Aktive Titel erscheinen in der Abstimmung.</div>
  </div>
  <div class="row">
    <a class="btn primary" href="#" data-open-dialog="dialog-new-song">+ Neuer Titel</a>
    <a class="btn" href="<?=h($base)?>/admin/abstimmungstitel_import.php">📥 Import / Export</a>
    <a class="btn" href="<?=h($base)?>/admin/bibliothek.php">📚 Bibliothek</a>
    <a class="btn" href="<?=h($base)?>/admin/">← Admin</a>
  </div>
</div>

<?php
$flashError      = sv_flash_get('error');
$archiveConflict = $_SESSION['archive_conflict'] ?? null;
unset($_SESSION['archive_conflict']);
if ($flashError && $flashError !== '__archive_conflict__') {
  echo '<div class="notice error" style="margin-bottom:12px">'.h($flashError).'</div>';
}
?>

<?php if ($archiveConflict): ?>
<dialog id="dialog-archive-conflict" class="sv-dialog" style="max-width:700px;width:95vw">
  <div class="sv-dialog__panel" style="max-height:85vh;display:flex;flex-direction:column">
    <div class="sv-dialog__head">
      <div>
        <div class="sv-dialog__title">Archiv-Konflikt: „<?=h($archiveConflict['song']['title'])?>"</div>
        <div class="sv-dialog__sub"><?=count($archiveConflict['matches'])?> Eintrag<?=count($archiveConflict['matches'])>1?'räge':' existiert'?> im Archiv mit diesem Titel</div>
      </div>
      <button class="sv-dialog__close" type="button" data-close-dialog>✕</button>
    </div>
    <div class="sv-dialog__section" style="overflow-y:auto;flex:1">

      <!-- Song-Daten -->
      <div style="background:#f5f2ee;border-radius:10px;padding:12px;margin-bottom:16px">
        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);margin-bottom:8px">Abstimmungstitel (wird archiviert)</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;font-size:14px">
          <div><span style="color:var(--muted)">Arrangeur:</span> <strong><?=h($archiveConflict['song']['arranger'] ?: '–')?></strong></div>
          <div><span style="color:var(--muted)">Komponist:</span> <strong><?=h($archiveConflict['song']['composer'] ?: '–')?></strong></div>
          <div><span style="color:var(--muted)">Dauer:</span> <strong><?=h($archiveConflict['song']['duration'] ?: '–')?></strong></div>
          <div><span style="color:var(--muted)">Verlag:</span> <strong><?=h($archiveConflict['song']['publisher'] ?: '–')?></strong></div>
        </div>
      </div>

      <div style="font-weight:700;font-size:13px;margin-bottom:10px">Mit welchem Archiveintrag verknüpfen?</div>

      <?php foreach ($archiveConflict['matches'] as $m): ?>
      <form method="post" style="margin-bottom:10px">
        <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
        <input type="hidden" name="action" value="to_archive">
        <input type="hidden" name="sid" value="<?=h($archiveConflict['sid'])?>">
        <input type="hidden" name="link_piece_id" value="<?=h($m['id'])?>">
        <div style="border:1.5px solid var(--border);border-radius:12px;padding:12px">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;font-size:14px;margin-bottom:10px">
            <div><span style="color:var(--muted)">Arrangeur:</span> <strong><?=h($m['arranger'] ?: '–')?></strong>
              <?php if(($m['arranger']??'') !== ($archiveConflict['song']['arranger']??'')): ?>
                <span class="badge" style="background:#fff8e1;color:#b8860b;border-color:rgba(184,134,11,.3)">abweichend</span>
              <?php endif; ?>
            </div>
            <div><span style="color:var(--muted)">Komponist:</span> <strong><?=h($m['composer'] ?: '–')?></strong></div>
            <div><span style="color:var(--muted)">Dauer:</span> <strong><?=h($m['duration'] ?: '–')?></strong>
              <?php if(!empty($archiveConflict['song']['duration']) && !empty($m['duration']) && $m['duration'] !== $archiveConflict['song']['duration']): ?>
                <span class="badge" style="background:#fff8e1;color:#b8860b;border-color:rgba(184,134,11,.3)">abweichend</span>
              <?php endif; ?>
            </div>
            <div><span style="color:var(--muted)">Verlag:</span> <strong><?=h($m['publisher'] ?: '–')?></strong></div>
          </div>
          <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
            <label class="toggle-wrap" style="margin:0">
              <input type="checkbox" name="merge_fields" value="1">
              <span class="toggle-track"></span>
              <span class="toggle-label" style="font-size:13px">Leere Archivfelder mit Abstimmungsdaten füllen</span>
            </label>
            <button class="btn primary" type="submit" style="margin-left:auto">Verknüpfen</button>
          </div>
        </div>
      </form>
      <?php endforeach; ?>

      <div style="border-top:1px solid var(--border);padding-top:14px;margin-top:4px">
        <div class="small" style="margin-bottom:8px;color:var(--muted)">Keiner passt — als neuen Archiveintrag anlegen:</div>
        <form method="post" style="display:inline">
          <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
          <input type="hidden" name="action" value="to_archive">
          <input type="hidden" name="sid" value="<?=h($archiveConflict['sid'])?>">
          <input type="hidden" name="force_link" value="1">
          <button class="btn" type="submit">+ Neu ins Archiv</button>
        </form>
      </div>
    </div>
  </div>
</dialog>
<script>document.addEventListener('DOMContentLoaded',function(){document.getElementById('dialog-archive-conflict').showModal();});</script>
<?php endif; ?>

<!-- Dialog: Neuen Titel hinzufügen -->
<dialog id="dialog-new-song" class="sv-dialog">
  <div class="sv-dialog__panel">
    <div class="sv-dialog__head">
      <div class="sv-dialog__title">Neuen Titel hinzufügen</div>
      <button class="sv-dialog__close" type="button" data-close-dialog aria-label="Schließen">✕</button>
    </div>
    <div class="sv-dialog__section">
      <form method="post" class="grid" style="gap:12px">
        <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
        <input type="hidden" name="action" value="create">
        <?= songFormFields([]) ?>
        <div class="row" style="gap:10px">
          <button class="btn primary" type="submit">Hinzufügen</button>
          <button class="btn" type="button" data-close-dialog>Abbrechen</button>
        </div>
      </form>
    </div>
  </div>
</dialog>

<!-- Suche & Filter -->
<div class="card" style="margin-bottom:12px">
  <form method="get" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <label style="flex:1;min-width:200px">Suche<br>
      <input class="input" type="text" name="q" value="<?=h($search)?>"
             placeholder="Titel, Komponist, Arrangeur, Genre…" style="width:100%;margin-top:5px">
    </label>
    <div style="display:flex;gap:8px;padding-bottom:1px">
      <button class="btn primary" type="submit">Suchen</button>
      <a class="btn" href="abstimmungstitel.php">Reset</a>
    </div>
  </form>
  <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-top:10px;padding-top:10px;border-top:1px solid var(--border)">
    <span style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--muted)">Spalten</span>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="s-col-composer" onchange="sCol('composer',this.checked);sCol('arranger',this.checked)" checked> Komponist / Arrangeur</label>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="s-col-genre"      onchange="sCol('genre',this.checked)"      checked> Genre</label>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="s-col-difficulty" onchange="sCol('difficulty',this.checked)" checked> Grad</label>
    <label style="display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:600;cursor:pointer"><input type="checkbox" id="s-col-duration"   onchange="sCol('duration',this.checked)"   checked> Länge</label>
    <span class="small" style="margin-left:auto"><?=count($songs)?> Treffer</span>
  </div>
</div>

<!-- Liste -->
<div class="card">
  <div class="table-scroll">
    <table>
      <thead>
        <tr>
          <?php
          function sSortTh(string $col, string $label, string $cur, string $dir, string $cls=''): string {
            $active=$cur===$col; $nd=($active&&$dir==='ASC')?'desc':'asc';
            $icon=$active?($dir==='ASC'?' ↑':' ↓'):'';
            $qs=http_build_query(array_filter(['q'=>$_GET['q']??'','sort'=>$col,'dir'=>$nd]));
            $st=($active?'color:var(--red);':'').'cursor:pointer;white-space:nowrap;user-select:none'.($col==='title'?';min-width:180px':'');
            $cc=$cls?' class="'.$cls.'"':'';
            return '<th'.$cc.' style="'.$st.'"><a href="?'.$qs.'" style="text-decoration:none;color:inherit">'.$label.$icon.'</a></th>';
          }
          echo sSortTh('title',      'Titel',         $sortBy,$sortDir);
          // Kombinierter Kopf
          $icK2 = $sortBy==='composer' ? ($sortDir==='ASC'?' ↑':' ↓') : '';
          $icA2 = $sortBy==='arranger' ? ($sortDir==='ASC'?' ↑':' ↓') : '';
          $ndK2 = ($sortBy==='composer'&&$sortDir==='ASC')?'desc':'asc';
          $ndA2 = ($sortBy==='arranger'&&$sortDir==='ASC')?'desc':'asc';
          $qK2  = http_build_query(array_filter(['q'=>$_GET['q']??'','sort'=>'composer','dir'=>$ndK2]));
          $qA2  = http_build_query(array_filter(['q'=>$_GET['q']??'','sort'=>'arranger','dir'=>$ndA2]));
          $stK2 = ($sortBy==='composer'?'color:var(--red)':'color:inherit').';cursor:pointer;user-select:none;display:block';
          $stA2 = ($sortBy==='arranger'?'color:var(--red)':'color:var(--muted)').';cursor:pointer;user-select:none;display:block;font-size:12px';
          echo '<th class="s-col s-col-composer s-col-arranger" style="white-space:nowrap"><a href="?'.$qK2.'" style="text-decoration:none;'.$stK2.'">Komponist'.$icK2.'</a><a href="?'.$qA2.'" style="text-decoration:none;'.$stA2.'">Arrangeur'.$icA2.'</a></th>';
          echo sSortTh('genre',      'Genre',         $sortBy,$sortDir,'s-col s-col-genre');
          echo sSortTh('difficulty', 'Grad', $sortBy,$sortDir,'s-col s-col-difficulty');
          echo sSortTh('duration',   'Länge',         $sortBy,$sortDir,'s-col s-col-duration');
          echo sSortTh('status',     'Status',        $sortBy,$sortDir);
          ?>
          <th style="width:44px"></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($songs as $s): ?>
        <tr>
          <td style="min-width:180px"><strong><?=h($s['title'])?></strong>
            <?php if(!empty($s['youtube_url'])): ?><div><a class="song-link" href="<?=h($s['youtube_url'])?>" target="_blank" rel="noopener">▶ YouTube öffnen</a></div>
            <?php else: ?><div class="small" style="color:#ccc">Kein YouTube-Link</div><?php endif; ?>
            <?php if($s['piece_id']): ?><div><span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid);font-size:11px">🔗 Archiv</span></div><?php endif; ?>
          </td>
          <td class="small s-col s-col-composer s-col-arranger" style="min-width:80px;max-width:130px">
            <?=h($s['composer'] ?: '–')?>
            <?php if(!empty($s['arranger'])): ?><div style="color:var(--muted);font-size:12px">Arr. <?=h($s['arranger'])?></div><?php endif; ?>
          </td>
          <td class="small s-col s-col-genre" style="white-space:nowrap"><?=h($s['genre'] ?: '–')?></td>
          <td class="s-col s-col-difficulty" style="white-space:nowrap"><?=diffPill($s['difficulty'])?></td>
          <td class="small s-col s-col-duration" style="white-space:nowrap"><?=h($s['duration'] ?: '–')?></td>
          <td style="white-space:nowrap"><?= (int)$s['is_active']===1
            ? '<span class="badge" style="background:var(--green-light);color:var(--green);border-color:var(--green-mid)">aktiv</span>'
            : '<span class="badge">inaktiv</span>' ?>
          </td>
          <td style="white-space:nowrap;text-align:center">
            <div style="position:relative;display:inline-block">
              <button class="btn" style="padding:4px 10px;font-size:16px;line-height:1" onclick="songToggleMenu(this)">⋯</button>
              <div class="song-menu" style="display:none;position:fixed;background:#fff;border:1.5px solid var(--border);border-radius:12px;box-shadow:0 4px 16px rgba(0,0,0,.1);z-index:9999;min-width:190px;overflow:hidden">
                <button class="song-menu-item" type="button" data-open-dialog="edit-song-<?=h($s['id'])?>">✏️ Bearbeiten</button>
                <?php if(!$s['piece_id']): ?>
                <form method="post"><input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>"><input type="hidden" name="sid" value="<?=h($s['id'])?>">
                  <button class="song-menu-item" name="action" value="to_archive" type="submit">📚 → Archiv</button>
                </form>
                <?php else: ?><div class="song-menu-item" style="opacity:.5;cursor:default">📚 Bereits im Archiv</div><?php endif; ?>
                <form method="post"><input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>"><input type="hidden" name="sid" value="<?=h($s['id'])?>">
                  <button class="song-menu-item" name="action" value="toggle_active" type="submit"><?= $s['is_active'] ? '⏸ Deaktivieren' : '▶ Aktivieren' ?></button>
                </form>
                <form method="post" onsubmit="return confirm('<?= $s['piece_id'] ? 'Titel löschen? Stimmen bleiben im Archiv.' : 'Titel löschen? Stimmen gehen verloren.' ?>')">
                  <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>"><input type="hidden" name="sid" value="<?=h($s['id'])?>">
                  <button class="song-menu-item" name="action" value="delete" type="submit" style="color:var(--red)">🗑 Löschen</button>
                </form>
              </div>
            </div>

            <dialog id="edit-song-<?=h($s['id'])?>" class="sv-dialog">
              <div class="sv-dialog__panel">
                <div class="sv-dialog__head">
                  <div>
                    <div class="sv-dialog__title">Titel bearbeiten</div>
                    <div class="sv-dialog__sub">Stimmen bleiben erhalten.</div>
                  </div>
                  <button class="sv-dialog__close" type="button" data-close-dialog aria-label="Schließen">✕</button>
                </div>
                <div class="sv-dialog__section">
                  <form method="post" class="grid" style="gap:12px">
                    <input type="hidden" name="csrf" value="<?=h(sv_csrf_token())?>">
                    <input type="hidden" name="sid"  value="<?=h($s['id'])?>">
                    <input type="hidden" name="action" value="update">
    <input type="hidden" name="_q"    value="<?=h($_GET['q']    ?? '')?>">
    <input type="hidden" name="_sort" value="<?=h($_GET['sort'] ?? '')?>">
    <input type="hidden" name="_dir"  value="<?=h($_GET['dir']  ?? '')?>">
                    <?= songFormFields($s) ?>
                    <?php if($s['piece_id']): ?>
                      <div class="small" style="color:var(--muted)">🔗 Verknüpft mit Archiv: <strong><?=h($s['piece_title']??'')?></strong></div>
                    <?php endif; ?>
                    <div class="row" style="gap:10px">
                      <button class="btn primary" type="submit">Speichern</button>
                      <button class="btn" type="button" data-close-dialog>Abbrechen</button>
                    </div>
                  </form>
                </div>
              </div>
            </dialog>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if(!$songs): ?>
        <tr><td colspan="8" class="small"><?= $search !== '' ? 'Keine Treffer für „'.h($search).'".' : 'Noch keine Titel.' ?></td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
(function(){
  document.addEventListener('click', function(e){
    var o = e.target.closest('[data-open-dialog]');
    if(o){ var d = document.getElementById(o.getAttribute('data-open-dialog')); if(d) d.showModal(); return; }
    var c = e.target.closest('[data-close-dialog]');
    if(c){ var d = c.closest('dialog'); if(d) d.close(); }
  });
  document.querySelectorAll('dialog.sv-dialog').forEach(function(d){
    // backdrop click intentionally disabled
  });
})();
</script>


<script>
function buildSearchQuery(form, type) {
  var title    = ((form.querySelector('[name="title"]')    || {}).value || '').trim();
  var composer = ((form.querySelector('[name="composer"]') || {}).value || '').trim();
  var arranger = ((form.querySelector('[name="arranger"]') || {}).value || '').trim();
  if (!title) return '';
  var parts = [title];
  if (arranger) parts.push(arranger);
  else if (composer) parts.push(composer);
  if (type === 'google') parts.push('Blasorchester OR "concert band"');
  return parts.join(' ');
}
function openSearchWindow(btn, type) {
  var form = btn.closest('form');
  if (!form) return;
  var query = buildSearchQuery(form, type);
  if (!query) { alert('Bitte zuerst einen Titel eingeben.'); return; }
  var url = type === 'youtube'
    ? 'https://www.youtube.com/results?search_query=' + encodeURIComponent(query)
    : 'https://www.google.com/search?q=' + encodeURIComponent(query);
  var win = window.open(url, 'klangvotum_search_window_' + type, 'popup=yes,width=1280,height=900,left=80,top=60,resizable=yes,scrollbars=yes');
  if (!win) alert('Das Suchfenster wurde vom Browser blockiert. Bitte Popups für diese Seite erlauben.');
  else { try { win.focus(); } catch(e) {} }
}
</script>

<style>
.col-hidden { display:none!important; }
.song-menu-item { display:block;width:100%;text-align:left;padding:9px 14px;font-size:13px;font-weight:600;background:none;border:none;cursor:pointer;color:var(--text);border-bottom:1px solid var(--border); }
.song-menu-item:last-child { border-bottom:none; }
.song-menu-item:hover { background:#faf8f5; }
.song-menu form { margin:0; }
</style>
<script>
function sCol(name, show) {
  document.querySelectorAll('.s-col-'+name).forEach(function(el){ el.classList.toggle('col-hidden',!show); });
  var p=JSON.parse(localStorage.getItem('song_cols')||'{}'); p[name]=show; localStorage.setItem('song_cols',JSON.stringify(p));
}
document.addEventListener('DOMContentLoaded', function(){
  var p=JSON.parse(localStorage.getItem('song_cols')||'{}');
  ['composer','arranger','genre','difficulty','duration'].forEach(function(col){
    if(p[col]===false){ sCol(col,false); var c=document.getElementById('s-col-'+col); if(c) c.checked=false; }
  });
});
function songToggleMenu(btn) {
  var menu=btn.nextElementSibling; var isOpen=menu.style.display!=='none';
  songCloseMenus();
  if(!isOpen){
    menu.style.display='block';
    var r=btn.getBoundingClientRect(); var mh=menu.offsetHeight||120;
    menu.style.top=(window.innerHeight-r.bottom<mh+8)?(r.top-mh-4)+'px':(r.bottom+4)+'px';
    menu.style.right=(window.innerWidth-r.right)+'px';
    setTimeout(function(){ document.addEventListener('click',songCloseOnOutside); },0);
  }
}
function songCloseMenus() {
  document.querySelectorAll('.song-menu').forEach(function(m){m.style.display='none';});
  document.removeEventListener('click',songCloseOnOutside);
}
function songCloseOnOutside(e) {
  if(!e.target.closest('.song-menu')&&!e.target.closest('[onclick*="songToggleMenu"]')) songCloseMenus();
}
</script>

<script>
function toggleYtRequired(btn) {
  var wrap = btn.closest('label');
  var inp  = wrap.querySelector('.yt-input');
  var lbl  = wrap.querySelector('.yt-label');
  if (!inp) return;
  if (inp.hasAttribute('required')) {
    inp.removeAttribute('required');
    inp.placeholder = 'https://youtu.be/… (optional)';
    btn.textContent = 'Pflicht wiederherstellen';
    btn.style.cssText = 'font-size:11px;padding:2px 8px;background:var(--red-soft);border-color:rgba(193,9,15,.3);color:var(--red)';
    if (lbl) lbl.textContent = 'YouTube URL (optional)';
  } else {
    inp.setAttribute('required','');
    inp.placeholder = 'https://youtu.be/…';
    btn.textContent = 'Pflicht aufheben';
    btn.style.cssText = 'font-size:11px;padding:2px 8px';
    if (lbl) lbl.textContent = 'YouTube URL *';
  }
}
</script>
<?php sv_footer(); ?>
