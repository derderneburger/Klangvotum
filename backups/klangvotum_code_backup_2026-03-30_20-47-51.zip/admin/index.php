<?php
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/layout.php';

$u   = sv_require_admin();
$pdo = sv_pdo();
$base = sv_base_url();

$top5 = $pdo->query("
  SELECT s.id, s.title, s.youtube_url,
         SUM(v.vote='ja') AS ja,
         SUM(v.vote='nein') AS nein,
         SUM(v.vote='neutral') AS neutral,
         (SUM(v.vote='ja') - SUM(v.vote='nein')) AS score
  FROM songs s
  LEFT JOIN votes v ON v.song_id = s.id
  WHERE s.is_active=1
  GROUP BY s.id
  ORDER BY score DESC, ja DESC, s.id ASC
  LIMIT 5
")->fetchAll();

$stats = $pdo->query("
  SELECT
    (SELECT COUNT(*) FROM users WHERE is_active=1)   AS users_active,
    (SELECT COUNT(*) FROM users WHERE is_admin=1 AND is_active=1) AS admins_active,
    (SELECT COUNT(*) FROM songs WHERE is_active=1)   AS songs_active,
    (SELECT COUNT(*) FROM songs WHERE is_active=0)   AS songs_inactive,
    (SELECT COUNT(*) FROM votes v
      JOIN users u ON u.id=v.user_id AND u.is_active=1
      JOIN songs s ON s.id=v.song_id AND s.is_active=1
    ) AS votes_count
")->fetch();

$activeUsers = $pdo->query("
  SELECT u.id, u.username, u.display_name, u.is_admin, ua.last_activity
  FROM users u
  JOIN user_activity ua ON ua.user_id=u.id
  WHERE u.is_active=1 AND ua.last_activity >= (NOW() - INTERVAL 5 MINUTE)
  ORDER BY ua.last_activity DESC, u.display_name ASC
")->fetchAll();

$onlineUsers = $pdo->query("
  SELECT u.id, u.username, u.display_name, u.is_admin, ua.last_activity
  FROM users u
  JOIN user_activity ua ON ua.user_id=u.id
  WHERE u.is_active=1
    AND ua.last_activity >= (NOW() - INTERVAL 20 MINUTE)
    AND ua.last_activity < (NOW() - INTERVAL 5 MINUTE)
  ORDER BY ua.last_activity DESC, u.display_name ASC
")->fetchAll();

$usersActive  = (int)($stats['users_active']  ?? 0);
$adminsActive = (int)($stats['admins_active'] ?? 0);
$songsActive  = (int)($stats['songs_active']  ?? 0);
$songsInactive= (int)($stats['songs_inactive']?? 0);
$votesCount   = (int)($stats['votes_count']   ?? 0);
$votesPossible= $usersActive * $songsActive;
$progressPct  = $votesPossible > 0 ? (int)round(($votesCount/$votesPossible)*100) : 0;

$maxAbs = 1;
foreach ($top5 as $r) $maxAbs = max($maxAbs, abs((int)$r['score']));
$frozen = sv_is_frozen();

function sv_time_ago(?string $dt): string {
  if(!$dt) return 'unbekannt';
  $ts = strtotime($dt);
  if(!$ts) return 'unbekannt';
  $d = time() - $ts;
  if($d < 60) return 'gerade eben';
  if($d < 3600) return (int)floor($d/60).' Min.';
  if($d < 86400) return (int)floor($d/3600).' Std.';
  return (int)floor($d/86400).' Tg.';
}

sv_header('Admin', $u);
?>

<?php if($frozen): ?>
<div class="freeze-banner" style="margin-bottom:16px">🔒 <span><strong>Abstimmung ist eingefroren.</strong> Teilnehmer können keine Stimmen ändern.</span></div>
<?php endif; ?>

<div class="page-header" style="margin-bottom:16px">
  <div><h2>Admin Dashboard</h2></div>
</div>

<!-- Stat Cards -->
<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-label">👥 Nutzer</div>
    <div class="stat-value"><?=h($usersActive)?></div>
    <div class="stat-sub">aktiv<?php if($adminsActive): ?> · <?=h($adminsActive)?> Admin<?= $adminsActive!==1?'s':'' ?><?php endif; ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">🗳️ Stimmen</div>
    <div class="stat-value"><?=h($votesCount)?></div>
    <div class="stat-sub">von <?=h($votesPossible)?> möglich</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">🎵 Titel</div>
    <div class="stat-value"><?=h($songsActive)?></div>
    <div class="stat-sub">aktiv<?php if($songsInactive): ?> · <?=h($songsInactive)?> inaktiv<?php endif; ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">📊 Fortschritt</div>
    <div class="stat-value"><?=h($progressPct)?>%</div>
    <div class="stat-sub" style="margin-bottom:8px">gesamt</div>
    <div class="progress"><div style="width:<?=$progressPct?>%"></div></div>
  </div>
</div>

<!-- Top 5 -->
<div class="card" style="margin-bottom:16px">
  <h3>🔥 Top 5 aktuell</h3>
  <div class="small" style="margin-bottom:14px">Score = Ja − Nein. Neutral zählt nicht.</div>
  <div style="overflow-x:auto">
    <table>
      <thead>
        <tr><th>#</th><th>Titel</th><th>Ja</th><th>Neutral</th><th>Nein</th><th>Score</th><th style="min-width:90px">Trend</th></tr>
      </thead>
      <tbody>
      <?php $i=1; foreach($top5 as $r):
        $score = (int)$r['score'];
        $w     = (int)round($maxAbs ? abs($score)/$maxAbs*100 : 0);
        $pillClass = $score > 0 ? 'pos' : ($score < 0 ? 'neg' : 'zero');
        $barClass  = $score >= 0 ? 'heat-pos' : 'heat-neg';
      ?>
        <tr>
          <td><span class="rank-num"><?=h($i++)?></span></td>
          <td>
            <strong><?=h($r['title'])?></strong>
            <?php if(!empty($r['youtube_url'])): ?>
              <div><a class="song-link" href="<?=h($r['youtube_url'])?>" target="_blank" rel="noopener">▶ YouTube öffnen</a></div>
            <?php endif; ?>
          </td>
          <td><?=h((int)$r['ja'])?></td>
          <td><?=h((int)$r['neutral'])?></td>
          <td><?=h((int)$r['nein'])?></td>
          <td>
            <?php
              $scBg     = $score>0?'var(--green-light)':($score<0?'var(--red-soft)':'#f5f2ee');
              $scColor  = $score>0?'var(--green)':($score<0?'var(--red)':'var(--muted)');
              $scBorder = $score>0?'var(--green-mid)':($score<0?'rgba(193,9,15,.3)':'#ddd');
            ?>
            <div style="display:inline-flex;flex-direction:column;align-items:center;background:<?=$scBg?>;color:<?=$scColor?>;border:1.5px solid <?=$scBorder?>;border-radius:10px;padding:5px 12px;min-width:44px;text-align:center">
              <span style="font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;line-height:1"><?= $score>0?'+':'' ?><?=h($score)?></span>
              <span style="font-size:9px;font-weight:700;letter-spacing:.06em;opacity:.7;margin-top:1px">SCORE</span>
            </div>
          </td>
          <td><div class="heat-bar"><div class="heat-fill <?=h($barClass)?>" style="width:<?=$w?>%"></div></div></td>
        </tr>
      <?php endforeach; ?>
      <?php if(!$top5): ?><tr><td colspan="7" class="small">Noch keine Titel oder Stimmen.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Online Users -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
  <div class="card">
    <h3 style="margin-bottom:10px"><span class="online-dot dot-green"></span>Aktiv <span class="badge" style="vertical-align:middle"><?=count($activeUsers)?></span></h3>
    <div class="small" style="margin-bottom:10px">Letzte 5 Minuten</div>
    <?php if($activeUsers): foreach($activeUsers as $ou): ?>
      <div class="user-row">
        <div style="font-weight:700"><?=h($ou['display_name'] ?: $ou['username'])?><?php if((int)$ou['is_admin']): ?> <?= sv_role_badge($ou['role'] ?? 'admin') ?><?php endif; ?></div>
        <span class="small">vor <?=h(sv_time_ago($ou['last_activity']))?></span>
      </div>
    <?php endforeach; else: ?>
      <div class="small">Niemand gerade aktiv.</div>
    <?php endif; ?>
  </div>
  <div class="card">
    <h3 style="margin-bottom:10px"><span class="online-dot dot-yellow"></span>Online <span class="badge" style="vertical-align:middle"><?=count($onlineUsers)?></span></h3>
    <div class="small" style="margin-bottom:10px">Letzte 20 Minuten (ohne Aktive)</div>
    <?php if($onlineUsers): foreach($onlineUsers as $ou): ?>
      <div class="user-row">
        <div style="font-weight:700"><?=h($ou['display_name'] ?: $ou['username'])?></div>
        <span class="small">vor <?=h(sv_time_ago($ou['last_activity']))?></span>
      </div>
    <?php endforeach; else: ?>
      <div class="small">Keine weiteren Nutzer online.</div>
    <?php endif; ?>
  </div>
</div>

<!-- Admin Grid -->
<div class="admin-grid">
  <div class="admin-section-card">
    <h3>Abstimmung</h3>
    <div class="admin-btn-row">
      <a class="btn" href="<?=h($base)?>/admin/abstimmungstitel.php">🎵 Titel verwalten</a>
      <a class="btn" href="<?=h($base)?>/admin/freeze.php">❄️ Einfrieren</a>
      <a class="btn" href="<?=h($base)?>/admin/kartenanzeige.php">🎨 Anzeige</a>
    </div>
    <div class="small">Titel zur Abstimmung stellen und Abstimmung sperren.</div>
  </div>
  <div class="admin-section-card">
    <h3>Auswertung</h3>
    <div class="admin-btn-row">
      <a class="btn" href="<?=h($base)?>/admin/progress.php">📈 Fortschritt</a>
      <a class="btn" href="<?=h($base)?>/admin/results.php">📊 Ergebnisse</a>
      <a class="btn" href="<?=h($base)?>/admin/votes.php">🗳️ Stimmen</a>
    </div>
    <div class="small">Wer hat abgestimmt, aggregierte Ergebnisse und Detailansicht.</div>
  </div>
  <div class="admin-section-card">
    <h3>Titel Archiv</h3>
    <div class="admin-btn-row">
      <a class="btn" href="<?=h($base)?>/admin/bibliothek.php">📚 Bibliothek</a>
      <a class="btn" href="<?=h($base)?>/admin/bibliothek_inhaltsverzeichnis.php" target="_blank">📄 Inhaltsverzeichnis</a>
    </div>
    <div class="small">Alle Stücke die das Orchester besitzt oder je gespielt hat.</div>
  </div>
  <div class="admin-section-card">
    <h3>Teilnehmer</h3>
    <div class="admin-btn-row">
      <a class="btn" href="<?=h($base)?>/admin/users.php">👥 Benutzer</a>
    </div>
    <div class="small">Zugänge anlegen, deaktivieren oder Passwörter zurücksetzen.</div>
  </div>
  <div class="admin-section-card" style="grid-column:1/-1">
    <h3>Wartung</h3>
    <div class="admin-btn-row">
      <a class="btn" href="<?=h($base)?>/admin/backup.php">💾 Backup</a>
      <a class="btn" href="<?=h($base)?>/admin/logininfo.php">🔐 Login-Infos</a>
      <a class="btn" href="<?=h($base)?>/admin/sysinfo.php">🖥️ Systeminfo</a>
    </div>
  </div>
</div>

<?php sv_footer(); ?>
